# Test results (nothing invented)
Environment of the authoring sandbox: JDK 21, Python 3.12, Node. **No Gradle, Kotlin compiler, Android SDK, emulator,
Firebase emulator or network.** So the Gradle build, Kotlin tests and lint could not be run here.

## Actually executed here
| Check | Result |
|---|---|
| `tools/http-harness/Harness.java` (Java port of the AI request policy, REAL local HTTP server) | **22 passed, 0 failed** (log: docs/http-harness-output.txt) |
| Manifest permissions vs code (7 declared, all used; no unused/missing; flashlight/volume/media keys need none) | PASS |
| firestore.rules vs every operation in Cloud.kt (8 operations, 3 field whitelists, no deletes) | PASS (static text cross-check) |
| Reminder overflow guard (Python mirror) | PASS |
| Reminder parsing (8 inputs) and command routing (17 inputs) - Python ports from round 1 | PASS |
| Brackets of 14 main + 7 test Kotlin files, symbol cross-check, 7 XML files well-formed, 2 workflow YAMLs parse, rules-test JS syntax (`node --check`), JSON configs | PASS |

## Written but NOT run (will run in GitHub Actions)
| Suite | Tests | Where |
|---|---|---|
| BrainExecuteTest (fake transport: success, header-only key, 401/403/404/400/418 no retry, 429 backoff, 5xx x4, timeout, IO, cancel, malformed, model discovery) | 14 | `gradle :app:testDebugUnitTest` |
| BrainHttpTest (MockWebServer: real sockets, 401 body, read timeout, cancel, retry 503, model discovery) | 6 | same |
| BrainTest, PhoneTest, RemindersParseTest (incl. overflow) | 10 + 1 + 7 | same |
| PairingLogicTest (codes, expiry, accept rule, creds, labels, **rules<->Cloud.kt parity**) | 11 | same |
| CloudFriendlyTest (Firebase error mapping) | 4 | same |
| rules.test.js (30 emulator tests of every Cloud.kt operation, incl. atomic accept, single use, strangers, expiry) | 31 | job `firestore-rules` |

## Not run, no result exists
Gradle configuration, manifest merge, Kotlin compile, the Kotlin unit tests above, Android lint, APK build, Firestore
emulator tests, and ALL on-device behaviour (voice, wake word, flashlight, volume/media keys, alarms, reminders,
notifications, Firebase login/pairing, real Anthropic calls).

**Build: NOT RUN. Compile: UNKNOWN. APK: NOT BUILT. Lint: NOT RUN.**
