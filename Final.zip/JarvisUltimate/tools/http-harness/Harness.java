import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.*;
import java.util.function.*;

/** Java port of Brain.execute/httpCall/fetchModels policy, run against a REAL local HTTP server (real sockets, timeouts, disconnect). */
public class Harness {
    static final int MAX_ATTEMPTS = 4;
    static long backoff(int a) { return Math.min(1000L << a, 8000L); }
    record Resp(int code, String body) {}
    static class Result { String ok; String err; List<Long> sleeps = new ArrayList<>(); int calls; public String toString(){return ok!=null?"Ok("+ok+")":"Err("+err+")";} }

    static Resp http(String method, String url, Map<String,String> h, String body, int connMs, int readMs, AtomicReference<HttpURLConnection> holder) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        if (holder != null) holder.set(c);
        c.setRequestMethod(method); c.setConnectTimeout(connMs); c.setReadTimeout(readMs);
        for (var e : h.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
        if (body != null) { c.setDoOutput(true); try (OutputStream o = c.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); } }
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        String txt = in == null ? "" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
        c.disconnect();
        return new Resp(code, txt);
    }
    static String detail(String t) { var m = java.util.regex.Pattern.compile("\"message\"\\s*:\\s*\"([^\"]*)\"").matcher(t); return m.find() ? m.group(1) : t.substring(0, Math.min(200, t.length())); }

    static Result execute(String url, String key, int readMs, String body) {
        Result r = new Result();
        Map<String,String> h = Map.of("x-api-key", key, "anthropic-version", "2023-06-01", "content-type", "application/json");
        String last = "Unknown error";
        for (int a = 0; a < MAX_ATTEMPTS; a++) {
            r.calls++;
            try {
                Resp x = http("POST", url, h, body, 2000, readMs, null);
                if (x.code >= 200 && x.code < 300) { r.ok = x.body.contains("\"text\"") ? "parsed" : null; if (r.ok == null) r.err = "empty"; return r; }
                String d = detail(x.body);
                switch (x.code) {
                    case 401 -> { r.err = "API key galat (401)"; return r; }
                    case 403 -> { r.err = "permission (403): " + d; return r; }
                    case 404 -> { r.err = "Model nahi mila (404)"; return r; }
                    case 400 -> { r.err = "Request galat (400): " + d; return r; }
                    case 429, 500, 502, 503, 504, 529 -> last = "Server busy (" + x.code + "): " + d;
                    default -> { r.err = "Error " + x.code + ": " + d; return r; }
                }
            } catch (SocketTimeoutException e) { last = "Server ne time par jawab nahi diya."; }
              catch (IOException e) { last = "Network problem: " + e.getMessage(); }
            if (a < MAX_ATTEMPTS - 1) r.sleeps.add(backoff(a));   // recorded, not slept (policy check)
        }
        r.err = last; return r;
    }

    static int pass = 0, fail = 0;
    static void check(String name, boolean ok, String info) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + name + "  " + info); }

    public static void main(String[] a) throws Exception {
        HttpServer srv = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        Map<String, Deque<int[]>> unused = new HashMap<>();
        AtomicInteger count = new AtomicInteger();
        AtomicReference<String> lastKey = new AtomicReference<>(), lastVer = new AtomicReference<>(), lastBody = new AtomicReference<>(), lastMethod = new AtomicReference<>(), lastPath = new AtomicReference<>();
        // behaviour chosen per path
        Map<String, Function<Integer, Object[]>> script = new ConcurrentHashMap_<>();
        srv.createContext("/", ex -> {
            int n = count.incrementAndGet();
            lastKey.set(ex.getRequestHeaders().getFirst("x-api-key")); lastVer.set(ex.getRequestHeaders().getFirst("anthropic-version"));
            lastMethod.set(ex.getRequestMethod()); lastPath.set(ex.getRequestURI().toString());
            lastBody.set(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            String p = ex.getRequestURI().getPath();
            Object[] s = script.get(p).apply(n);          // {status, body, delayMs}
            try { Thread.sleep((Integer) s[2]); } catch (InterruptedException ignored) {}
            byte[] b = ((String) s[1]).getBytes(StandardCharsets.UTF_8);
            try { ex.sendResponseHeaders((Integer) s[0], b.length); ex.getResponseBody().write(b); } catch (IOException ignored) {} finally { ex.close(); }
        });
        srv.setExecutor(java.util.concurrent.Executors.newCachedThreadPool());
        srv.start();
        String base = "http://127.0.0.1:" + srv.getAddress().getPort();
        String okBody = "{\"content\":[{\"type\":\"text\",\"text\":\"hello\"}]}";
        String reqBody = "{\"model\":\"m\",\"system\":\"s\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}";
        BiConsumer<String, Function<Integer, Object[]>> on = script::put;

        // 1 success + headers/body
        count.set(0); on.accept("/ok", n -> new Object[]{200, okBody, 0});
        Result r = execute(base + "/ok", "sk-ant-KEY", 2000, reqBody);
        check("success", "parsed".equals(r.ok) && count.get() == 1, r + " calls=" + count.get());
        check("api key sent as header only", "sk-ant-KEY".equals(lastKey.get()) && !lastBody.get().contains("sk-ant-KEY"), "hdr=" + lastKey.get());
        check("anthropic-version header", "2023-06-01".equals(lastVer.get()), lastVer.get());
        check("POST body delivered", lastBody.get().equals(reqBody), "");

        // 2 auth/client errors are not retried, error body (errorStream) is read
        for (int code : new int[]{401, 403, 404, 400, 418}) {
            count.set(0); on.accept("/e" + code, n -> new Object[]{code, "{\"error\":{\"message\":\"detail-" + code + "\"}}", 0});
            r = execute(base + "/e" + code, "k", 2000, reqBody);
            check("HTTP " + code + " not retried", count.get() == 1 && r.err != null && r.err.contains("" + code), r + " calls=" + count.get());
        }
        // 3 retry then success (429, 429, 200)
        count.set(0); on.accept("/rl", n -> n < 3 ? new Object[]{429, "{\"error\":{\"message\":\"slow down\"}}", 0} : new Object[]{200, okBody, 0});
        r = execute(base + "/rl", "k", 2000, reqBody);
        check("429,429,200 -> Ok after 3 calls, backoff 1000,2000", "parsed".equals(r.ok) && r.calls == 3 && r.sleeps.equals(List.of(1000L, 2000L)), r + " sleeps=" + r.sleeps);
        // 4 persistent 5xx
        for (int code : new int[]{500, 502, 503, 504, 529}) {
            count.set(0); on.accept("/s" + code, n -> new Object[]{code, "{\"error\":{\"message\":\"overloaded\"}}", 0});
            r = execute(base + "/s" + code, "k", 2000, reqBody);
            check(code + " x4 -> Err, 4 calls, backoff 1000/2000/4000", r.err != null && r.err.contains("Server busy (" + code + ")") && count.get() == 4 && r.sleeps.equals(List.of(1000L, 2000L, 4000L)), r + " calls=" + count.get());
        }
        // 5 read timeout (server sleeps 1500 ms, client readTimeout 300 ms) -> retried 4x -> Err
        count.set(0); on.accept("/slow", n -> new Object[]{200, okBody, 1500});
        long t0 = System.nanoTime(); r = execute(base + "/slow", "k", 300, reqBody); long ms = (System.nanoTime() - t0) / 1_000_000;
        check("read timeout -> SocketTimeout, 4 attempts", r.err != null && r.err.contains("time par jawab nahi") && r.calls == 4, r + " took " + ms + "ms");
        // 6 timeout then success
        count.set(0); on.accept("/slow1", n -> n == 1 ? new Object[]{200, okBody, 1500} : new Object[]{200, okBody, 0});
        r = execute(base + "/slow1", "k", 300, reqBody);
        check("timeout then success recovers", "parsed".equals(r.ok) && r.calls == 2, r + "");
        // 7 connection refused
        r = execute("http://127.0.0.1:1/v1/messages", "k", 300, reqBody);
        check("connection refused -> Network problem after 4 attempts", r.err != null && r.err.startsWith("Network problem") && r.calls == 4, r + "");
        // 8 empty/garbage success body
        count.set(0); on.accept("/junk", n -> new Object[]{200, "<html>login</html>", 0});
        r = execute(base + "/junk", "k", 2000, reqBody);
        check("200 with non-API body -> Err", r.err != null, r + "");
        // 9 model discovery: GET, headers, 401
        count.set(0); on.accept("/v1/models", n -> new Object[]{200, "{\"data\":[{\"id\":\"claude-sonnet-5-5\"},{\"id\":\"claude-haiku-5-5\"}]}", 0});
        Resp m = http("GET", base + "/v1/models?limit=50", Map.of("x-api-key", "k", "anthropic-version", "2023-06-01"), null, 2000, 2000, null);
        check("model discovery GET /v1/models?limit=50", m.code == 200 && m.body.contains("claude-haiku-5-5") && "GET".equals(lastMethod.get()) && lastPath.get().equals("/v1/models?limit=50") && "k".equals(lastKey.get()), lastMethod + " " + lastPath);
        on.accept("/v1/models", n -> new Object[]{401, "{\"error\":{\"message\":\"invalid x-api-key\"}}", 0});
        m = http("GET", base + "/v1/models?limit=50", Map.of("x-api-key", "bad"), null, 2000, 2000, null);
        check("model discovery 401 body readable", m.code == 401 && detail(m.body).equals("invalid x-api-key"), detail(m.body));
        // 10 cancellation: disconnect() from another thread aborts a blocked read quickly
        on.accept("/hang", n -> new Object[]{200, okBody, 8000});
        AtomicReference<HttpURLConnection> hold = new AtomicReference<>(); AtomicReference<Throwable> thrown = new AtomicReference<>();
        Thread t = new Thread(() -> { try { http("GET", base + "/hang", Map.of(), null, 2000, 30000, hold); } catch (Throwable e) { thrown.set(e); } });
        long c0 = System.nanoTime(); t.start(); Thread.sleep(400); hold.get().disconnect(); t.join(5000);
        long cms = (System.nanoTime() - c0) / 1_000_000;
        check("cancel (disconnect) aborts blocked call < 3s", !t.isAlive() && thrown.get() != null && cms < 3000, "took " + cms + "ms, " + thrown.get());
        srv.stop(0);
        System.out.println("\nHARNESS RESULT: " + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
    static class ConcurrentHashMap_<K,V> extends java.util.concurrent.ConcurrentHashMap<K,V> {}
}
