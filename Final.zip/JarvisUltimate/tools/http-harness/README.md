Real-socket check of the AI request policy (status mapping, retries/backoff, timeouts, model discovery, cancel).
It is a **Java port** of Brain.execute/httpCall (same rules), run with the JDK's HttpURLConnection against a local server.
It validates the policy and HttpURLConnection behaviour on a JVM; it does NOT run the Kotlin code and does not prove
Android's HttpURLConnection behaves identically. Run: `java Harness.java` (JDK 17+). Output of the last run: docs/http-harness-output.txt
