// Firestore security-rules tests. Mirrors EVERY operation in app/.../Cloud.kt.
// Run in CI (needs the Firestore emulator): `cd firebase-tests && npm install && npm test`.
import { readFileSync } from 'node:fs';
import { before, after, beforeEach, describe, it } from 'node:test';
import { initializeTestEnvironment, assertFails, assertSucceeds } from '@firebase/rules-unit-testing';
import {
  doc, getDoc, setDoc, addDoc, updateDoc, deleteDoc, collection, query, where, getDocs,
  writeBatch, serverTimestamp, Timestamp,
} from 'firebase/firestore';

let env;
const A = 'uidAlice';  // owns the code, accepts
const B = 'uidBob';    // joins with the code
const C = 'uidCarol';  // stranger
const CODE = 'ABCDEFGHJK';
const CODE2 = 'KLMNPQRSTU';
const mins = (n) => Timestamp.fromMillis(Date.now() + n * 60000);
const db = (uid) => env.authenticatedContext(uid).firestore();

before(async () => {
  env = await initializeTestEnvironment({
    projectId: 'demo-jarvis',
    firestore: { rules: readFileSync(new URL('../../firestore.rules', import.meta.url), 'utf8') },
  });
});
after(async () => { await env.cleanup(); });
beforeEach(async () => { await env.clearFirestore(); });

const codeDoc = (owner, extra = {}) => ({ ownerUid: owner, expiresAt: mins(10), purgeAt: mins(2880), used: false, ...extra });
const seedCode = (code = CODE, extra = {}) => env.withSecurityRulesDisabled(async (c) => {
  await setDoc(doc(c.firestore(), 'pairCodes', code), codeDoc(A, extra));
});
const pairingDoc = (members, requestedBy, status = 'pending', codeId = CODE) =>
  ({ members, requestedBy, status, codeId, createdAt: serverTimestamp() });
const seedPairing = (id = 'p1', status = 'pending', codeId = CODE) => env.withSecurityRulesDisabled(async (c) => {
  await setDoc(doc(c.firestore(), 'pairings', id), { members: [A, B], requestedBy: B, status, codeId, createdAt: Timestamp.now() });
});
const acceptBatch = (d, pid = 'p1', code = CODE) => {
  const b = writeBatch(d);
  b.update(doc(d, 'pairings', pid), { status: 'active' });
  b.update(doc(d, 'pairCodes', code), { used: true });
  return b;
};

describe('unauthenticated', () => {
  it('cannot read or write anything', async () => {
    const d = env.unauthenticatedContext().firestore();
    await assertFails(getDoc(doc(d, 'pairCodes', CODE)));
    await assertFails(setDoc(doc(d, 'users', A), { email: 'x@y.z' }));
  });
});

describe('users (Cloud.saveProfile)', () => {
  it('owner can merge-write whitelisted fields', async () => {
    await assertSucceeds(setDoc(doc(db(A), 'users', A), { email: 'a@b.co', device: 'Pixel', updatedAt: serverTimestamp() }, { merge: true }));
  });
  it('rejects unknown fields', async () => {
    await assertFails(setDoc(doc(db(A), 'users', A), { email: 'a@b.co', isAdmin: true }));
  });
  it('other users cannot read it', async () => {
    await env.withSecurityRulesDisabled(async (c) => setDoc(doc(c.firestore(), 'users', A), { email: 'a@b.co' }));
    await assertFails(getDoc(doc(db(B), 'users', A)));
  });
});

describe('pairCodes (Cloud.createPairCode / joinWithCode read)', () => {
  it('owner can create a valid code', async () => {
    await assertSucceeds(setDoc(doc(db(A), 'pairCodes', CODE), codeDoc(A)));
  });
  it('cannot create a code owned by someone else', async () => {
    await assertFails(setDoc(doc(db(B), 'pairCodes', CODE), codeDoc(A)));
  });
  it('rejects a code id with forbidden characters, extra fields or used=true', async () => {
    await assertFails(setDoc(doc(db(A), 'pairCodes', 'abcdefghij'), codeDoc(A)));
    await assertFails(setDoc(doc(db(A), 'pairCodes', CODE), codeDoc(A, { extra: 1 })));
    await assertFails(setDoc(doc(db(A), 'pairCodes', CODE), codeDoc(A, { used: true })));
  });
  it('rejects an expiry more than 30 minutes ahead', async () => {
    await assertFails(setDoc(doc(db(A), 'pairCodes', CODE), codeDoc(A, { expiresAt: mins(120) })));
  });
  it('any signed-in user can get by id, nobody can list', async () => {
    await seedCode();
    await assertSucceeds(getDoc(doc(db(B), 'pairCodes', CODE)));
    await assertFails(getDocs(collection(db(B), 'pairCodes')));
  });
});

describe('pairings create (Cloud.joinWithCode)', () => {
  beforeEach(async () => { await seedCode(); });
  it('requester can create a pending request for a valid code', async () => {
    await assertSucceeds(addDoc(collection(db(B), 'pairings'), pairingDoc([A, B], B)));
  });
  it('cannot impersonate: requestedBy must be me', async () => {
    await assertFails(addDoc(collection(db(B), 'pairings'), pairingDoc([A, B], A)));
  });
  it('cannot create as already active', async () => {
    await assertFails(addDoc(collection(db(B), 'pairings'), pairingDoc([A, B], B, 'active')));
  });
  it('members must include the code owner', async () => {
    await assertFails(addDoc(collection(db(B), 'pairings'), pairingDoc([C, B], B)));
  });
  it('owner cannot pair with themselves', async () => {
    await assertFails(addDoc(collection(db(A), 'pairings'), pairingDoc([A, A], A)));
  });
  it('fails for a used code', async () => {
    await env.withSecurityRulesDisabled(async (c) => updateDoc(doc(c.firestore(), 'pairCodes', CODE), { used: true }));
    await assertFails(addDoc(collection(db(B), 'pairings'), pairingDoc([A, B], B)));
  });
  it('fails for an expired code', async () => {
    await seedCode(CODE2, { expiresAt: Timestamp.fromMillis(Date.now() - 60000) });
    await assertFails(addDoc(collection(db(B), 'pairings'), pairingDoc([A, B], B, 'pending', CODE2)));
  });
  it('fails for a code that does not exist', async () => {
    await assertFails(addDoc(collection(db(B), 'pairings'), pairingDoc([A, B], B, 'pending', 'ZZZZZZZZZZ')));
  });
});

describe('pairings read (Cloud.pairings query)', () => {
  beforeEach(async () => { await seedPairing(); });
  it('members can query their pairings', async () => {
    await assertSucceeds(getDocs(query(collection(db(A), 'pairings'), where('members', 'array-contains', A))));
    await assertSucceeds(getDocs(query(collection(db(B), 'pairings'), where('members', 'array-contains', B))));
  });
  it('a stranger cannot read it or query it', async () => {
    await assertFails(getDoc(doc(db(C), 'pairings', 'p1')));
    await assertFails(getDocs(query(collection(db(C), 'pairings'), where('members', 'array-contains', A))));
  });
});

describe('pairings accept (Cloud.accept) - atomic and single use', () => {
  beforeEach(async () => { await seedCode(); await seedPairing(); });
  it('code owner can accept with the atomic batch', async () => {
    await assertSucceeds(acceptBatch(db(A)).commit());
  });
  it('requester cannot accept their own request', async () => {
    await assertFails(updateDoc(doc(db(B), 'pairings', 'p1'), { status: 'active' }));
    await assertFails(acceptBatch(db(B)).commit());
  });
  it('accept WITHOUT burning the code is denied', async () => {
    await assertFails(updateDoc(doc(db(A), 'pairings', 'p1'), { status: 'active' }));
  });
  it('a second pending request on the same code cannot be accepted after the first', async () => {
    await env.withSecurityRulesDisabled(async (c) =>
      setDoc(doc(c.firestore(), 'pairings', 'p2'), { members: [A, C], requestedBy: C, status: 'pending', codeId: CODE, createdAt: Timestamp.now() }));
    await assertSucceeds(acceptBatch(db(A), 'p1').commit());
    await assertFails(acceptBatch(db(A), 'p2').commit());
  });
  it('cannot accept after the 15 minute grace following expiry', async () => {
    await env.withSecurityRulesDisabled(async (c) =>
      updateDoc(doc(c.firestore(), 'pairCodes', CODE), { expiresAt: Timestamp.fromMillis(Date.now() - 20 * 60000) }));
    await assertFails(acceptBatch(db(A)).commit());
  });
  it('cannot change anything except status', async () => {
    await assertFails(updateDoc(doc(db(A), 'pairings', 'p1'), { members: [A, C] }));
  });
  it('stranger cannot touch the pairing', async () => {
    await assertFails(updateDoc(doc(db(C), 'pairings', 'p1'), { status: 'revoked' }));
  });
});

describe('pairCodes update (burn)', () => {
  beforeEach(async () => { await seedCode(); });
  it('non-owner cannot burn a code', async () => {
    await assertFails(updateDoc(doc(db(B), 'pairCodes', CODE), { used: true }));
  });
  it('owner cannot un-burn or edit other fields', async () => {
    await assertFails(updateDoc(doc(db(A), 'pairCodes', CODE), { expiresAt: mins(25) }));
    await env.withSecurityRulesDisabled(async (c) => updateDoc(doc(c.firestore(), 'pairCodes', CODE), { used: true }));
    await assertFails(updateDoc(doc(db(A), 'pairCodes', CODE), { used: false }));
  });
});

describe('pairings revoke (Cloud.revoke)', () => {
  beforeEach(async () => { await seedCode(); await seedPairing('p1', 'active'); });
  it('either member can revoke', async () => {
    await assertSucceeds(updateDoc(doc(db(B), 'pairings', 'p1'), { status: 'revoked' }));
  });
  it('a stranger cannot, and deletes are never allowed', async () => {
    await assertFails(updateDoc(doc(db(C), 'pairings', 'p1'), { status: 'revoked' }));
    await assertFails(deleteDoc(doc(db(A), 'pairings', 'p1')));
  });
});
