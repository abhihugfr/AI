# Audit (v0.2 -> v0.3)
Method: read every Kotlin/Gradle/XML/rules file; cross-file symbol check; bracket check; XML parse; logic ports in Python.
Nothing below was found by running the app; items are from code reading.

## Fixed
| # | Problem found | Fix |
|---|---|---|
| 1 | Notes/memories/chat/reminders stored as plain JSON; a parse error returned an empty list and the next write **erased the data** | Encrypted storage (Keystore-backed). Old files migrated once and deleted only after read-back verification. Corrupt payload kept under `json_corrupt` |
| 2 | AI request ran on a blocking socket: it could not be cancelled and held the UI until timeout | Cancellable HTTP (socket is disconnected on cancel); **Stop** button in chat |
| 3 | Linear retry, 3 attempts | Exponential backoff 1s/2s/4s (cap 8s), 4 attempts on 429/5xx/529/timeouts |
| 4 | No API-key sanity check, hardcoded model buttons only | Key format check, "Load models from API" (GET /v1/models), editable endpoint (https only) for a proxy |
| 5 | All memories sent on every AI call | Only memories relevant to the question (word overlap), else newest 5; `useMemory=false` for connection test |
| 6 | Voice commands hijacked normal sentences ("open source kya hai", "share market...", "battery kaise bachaye") | Command only if short and not an explain/how/why sentence; share needs `share text ...` or `share: ...` |
| 7 | Reminder silently lost when notifications are disabled | Warning shown when notifications are off |
| 8 | Firebase calls can hang forever offline | 15 s deadline, Hinglish error mapping, email/password validation |
| 9 | Firestore `users/{uid}` accepted any fields | Whitelisted fields only |
| 10 | Wake service restarted the recognizer in a tight loop on errors and ran forever | Exponential restart backoff, stop after 8 hard errors, auto-stop after 30 min without wake word |
| 11 | TTS could be asked to speak before init finished | Ready flag |
| 12 | No app icon, white launch flash, no `uses-feature required=false` for flash/mic | Adaptive icon, dark theme, uses-feature entries |
| 13 | Gradle: AGP 8.5 needed new Android Studio | AGP 8.2.2 + Gradle 8.7, Kotlin 1.9.24, JDK 17 |
| 14 | No CI, no tests, no lint config | GitHub Actions, 16 unit tests, lint report |

## Not fixed / residual risk
- Pairing code is readable by id by any signed-in user (needed for the join flow). 50-bit code + 10 min + single use; add Firebase App Check for real protection.
- Reminders use WorkManager (not exact); Doze can delay them by minutes.
- "Wake word" loops Android SpeechRecognizer: not low power, device/Google-app dependent, may beep, may use cloud recognition on some devices. Offline recognition is requested but not guaranteed.
- Background app launches (open app, settings, alarm, share) are blocked by Android from the wake service; the app says so.
- `androidx.security:security-crypto` may show deprecation warnings upstream; it still works.
- Messaging, signals, remote ring, location, FCM, QR pairing, AI-to-AI are **not implemented** (see below).

---
# Round 2 audit (v0.3 -> v0.4)
## Pairing / Firestore
| Claim / finding | Verdict |
|---|---|
| "accept() updates pairCodes but rules allow only the owner" | Re-read: the accepter is always the code owner (the create rule forces `ownerUid in members` and `ownerUid != requester`; only the non-requester may accept), so the owner-only rule on pairCodes was satisfied. The stated failure does not follow from the code. |
| Real defect A: single use not enforced. Several pending requests could use one code and all be accepted | Fixed: accept needs `get(code).used == false` AND `getAfter(code).used == true` (same batch burns it) |
| Real defect B: accept after the code doc was TTL-purged failed with NOT_FOUND, and TTL was on `expiresAt` | Fixed: separate `purgeAt` TTL field (2 days), accept window = expiry + 15 min in the rules, friendly error for denied/not-found |
| Rules loose: no createdAt check, no key requirements, no code-format check | Fixed (`hasAll`, `createdAt == request.time`, code regex) |
| Rules <-> Cloud.kt drift | Parity unit test + 30 emulator tests (not run here) |
## Runtime / lifecycle
| Finding | Fix |
|---|---|
| Reminder text with a huge number ("99999999999999999999 minutes") threw NumberFormatException = crash | `toLongOrNull`, cap 100000 units and 366 days |
| Wake service could go permanently deaf if TTS failed/never called back (listening only resumed in the TTS callback) | speak() result checked, 20 s watchdog, `finishSpeak()` runs exactly once |
| Foreground-service start without mic permission could crash on Android 14 | permission check before start, try/catch around startForeground, graceful stop |
| Rotation recreated the activity and silently cancelled an in-flight AI request | `configChanges` on MainActivity |
| Encrypted storage failing twice would crash the app at startup | Falls back to private plain storage and shows a warning in About |
| AI retry policy untestable | Extracted `execute()` with injectable transport; 20 tests |
## Build / CI
| Finding | Fix |
|---|---|
| APK uploaded before tests/lint ran | Order: config > manifest > compile > tests > lint > assemble > upload |
| Lint failures ignored | `abortOnError = true`, no continue-on-error |
| Wrapper jar missing | Cannot be produced offline and was NOT faked; `generate-wrapper` workflow generates it with Gradle and commits it |
