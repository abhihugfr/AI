# Architecture
Single `app` module, MVVM-lite for now (state in Compose, logic in objects). Move to ViewModels as screens grow.

- Brain.kt: Anthropic API (HttpURLConnection, retries, error mapping). Key from encrypted Prefs.
- Commands.kt: local command router (offline-capable) then AI fallback. `bg=true` from the wake service.
- Phone.kt: device actions. Reminders.kt: WorkManager reminders + notifications.
- Store.kt: JSON files in app-private storage: memories, notes, reminders, chat (not encrypted; secrets never go here).
- WakeService.kt: foreground mic service looping SpeechRecognizer for "JARVIS".
- Cloud.kt + firestore.rules: Firebase Auth + pairing. 

## Connected Mode data model (Firestore)
users/{uid}                      profile (own only)
pairCodes/{code}                 {ownerUid, expiresAt, used}  get-by-id only
pairings/{pid}                   {members[2], requestedBy, status pending|active|revoked, codeId, createdAt}
pairings/{pid}/messages/{mid}    (next) {from, type text|signal|cmd, body, sentAt, deliveredAt, readAt}
pairings/{pid}/location/{uid}    (next) {lat,lng,updatedAt,sharing}
Rules for the next stage: messages/location readable only by members of an ACTIVE pairing; sender == auth.uid.

## Remote-command safety (next stage design)
Allow-list only: `ping`, `status`, `ring`, `signal:<name>`, `location:request`. Each needs the receiver's
saved permission toggle. No shell, no arbitrary intents, no hidden actions. Delivery via FCM data message
(Cloud Function sends it; needs Blaze plan) or Firestore listener while app is open.
