package com.avi.jarvis
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

val Cyan = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifs.ensure(this)
        setContent { JarvisApp() }
    }
}

@Composable
fun JarvisApp() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val names = listOf("Core", "Chat", "Memory", "Connect", "Settings")
    val icons = listOf(Icons.Default.Home, Icons.Default.Send, Icons.Default.Menu, Icons.Default.Share, Icons.Default.Settings)
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Color.Black, surface = Color(0xFF06121C),
        onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Color.Black, bottomBar = {
            NavigationBar(containerColor = Color(0xFF040A10)) {
                names.forEachIndexed { i, n ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icons[i], n) }, label = { Text(n) })
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> Dashboard { tab = 1 }
                    1 -> ChatScreen()
                    2 -> MemoryScreen()
                    3 -> ConnectedScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }
}
