package com.avi.jarvis
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal typealias Transport = suspend (method: String, url: String, headers: Map<String, String>, body: String?) -> Pair<Int, String>

internal data class AiRequest(
    val endpoint: String, val apiKey: String, val model: String, val system: String,
    val history: List<Pair<String, String>>, val maxTokens: Int)

sealed class Ai {
    data class Ok(val text: String) : Ai()
    data class Err(val msg: String) : Ai()
}

object Brain {
    private const val VERSION = "2023-06-01"
    internal const val MAX_ATTEMPTS = 4
    internal const val CONNECT_MS = 15_000
    internal const val READ_MS = 60_000
    val MODELS = listOf("Sonnet" to "claude-sonnet-5-5", "Haiku" to "claude-haiku-5-5", "Opus" to "claude-opus-5-5")

    fun validKey(k: String): Boolean = k.trim().let { it.startsWith("sk-ant-") && it.length >= 20 }
    internal fun backoffMs(attempt: Int): Long = (1000L shl attempt).coerceAtMost(8000L)
    internal fun modelsUrl(endpoint: String): String = endpoint.replace("/messages", "/models")

    /** Memories that share words with the question first; falls back to the 5 newest. */
    internal fun relevantMemories(mem: List<Item>, query: String, max: Int = 10): List<Item> {
        val words = query.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 }.toSet()
        val scored = mem.map { m -> m to words.count { w -> m.text.lowercase().contains(w) } }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<Item, Int>> { it.second }.thenByDescending { it.first.time })
            .take(max).map { it.first }
        return if (scored.isNotEmpty()) scored else mem.takeLast(5)
    }

    fun systemPrompt(ctx: Context, useMemory: Boolean = true, query: String = ""): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
        val sb = StringBuilder(Prefs.get(ctx).persona).append("\nCurrent date/time: ").append(now).append('.')
        if (useMemory) {
            val mem = relevantMemories(Stores.get(ctx, "memories").all(), query)
            if (mem.isNotEmpty()) {
                sb.append("\nThings the owner asked you to remember:\n")
                mem.forEach { sb.append("- ").append(it.text).append('\n') }
            }
        }
        return sb.toString()
    }

    internal fun errorDetail(txt: String): String = try {
        JSONObject(txt).optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() } ?: txt.take(200)
    } catch (e: Exception) { txt.take(200) }

    internal fun parseResponse(txt: String): Ai = try {
        val arr = JSONObject(txt).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("type") == "text") sb.append(o.optString("text"))
        }
        if (sb.isBlank()) Ai.Err("AI ne khaali jawab diya.") else Ai.Ok(sb.toString().trim())
    } catch (e: Exception) { Ai.Err("Jawab samajh nahi aaya: ${e.message}") }

    internal fun parseModels(txt: String): List<String> = try {
        val arr = JSONObject(txt).getJSONArray("data")
        (0 until arr.length()).map { arr.getJSONObject(it).getString("id") }
    } catch (e: Exception) { emptyList() }

    /** Cancellable HTTP call: cancelling the coroutine disconnects the socket immediately (this is the "Stop" button). */
    internal suspend fun httpCall(
        method: String, url: String, headers: Map<String, String>, body: String?,
        connectMs: Int = CONNECT_MS, readMs: Int = READ_MS
    ): Pair<Int, String> = suspendCancellableCoroutine { cont ->
        val c = URL(url).openConnection() as HttpURLConnection
        cont.invokeOnCancellation { try { c.disconnect() } catch (e: Exception) { } }
        thread(name = "jarvis-http") {
            try {
                c.requestMethod = method
                c.connectTimeout = connectMs; c.readTimeout = readMs
                headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
                if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (cont.isActive) cont.resume(code to txt)
            } catch (e: Exception) {
                if (cont.isActive) cont.resumeWithException(e)
            } finally { try { c.disconnect() } catch (e: Exception) { } }
        }
    }

    internal fun buildBody(r: AiRequest): String {
        val msgs = JSONArray()
        r.history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        return JSONObject().put("model", r.model).put("max_tokens", r.maxTokens)
            .put("system", r.system).put("messages", msgs).toString()
    }

    internal fun headersFor(key: String): Map<String, String> =
        mapOf("x-api-key" to key, "anthropic-version" to VERSION, "content-type" to "application/json")

    /** The whole request/retry/error-mapping policy, free of Android so it can be unit-tested with a fake transport. */
    internal suspend fun execute(r: AiRequest, transport: Transport, sleep: suspend (Long) -> Unit = { delay(it) }): Ai {
        val body = buildBody(r)
        val headers = headersFor(r.apiKey)
        var lastErr = "Unknown error"
        for (attempt in 0 until MAX_ATTEMPTS) {
            try {
                val (code, txt) = transport("POST", r.endpoint, headers, body)
                if (code in 200..299) return parseResponse(txt)
                val detail = errorDetail(txt)
                when (code) {
                    401 -> return Ai.Err("API key galat ya expire hai (401). Settings mein check karo.")
                    403 -> return Ai.Err("Is key ko permission nahi hai (403): $detail")
                    404 -> return Ai.Err("Model nahi mila (404). Settings mein 'Load models' dabao ya naam check karo: ${r.model}")
                    400 -> return Ai.Err("Request galat (400): $detail")
                    429, 500, 502, 503, 504, 529 -> { lastErr = "Server busy ($code): $detail" }
                    else -> return Ai.Err("Error $code: $detail")
                }
            } catch (e: SocketTimeoutException) {
                lastErr = "Server ne time par jawab nahi diya."
            } catch (e: IOException) {
                lastErr = "Network problem: ${e.message}"
            }
            if (attempt < MAX_ATTEMPTS - 1) sleep(backoffMs(attempt))
        }
        return Ai.Err(lastErr)
    }

    internal suspend fun fetchModels(endpoint: String, key: String, transport: Transport): Pair<List<String>, String?> =
        try {
            val h = mapOf("x-api-key" to key, "anthropic-version" to VERSION)
            val (code, txt) = transport("GET", modelsUrl(endpoint) + "?limit=50", h, null)
            if (code in 200..299) {
                val ids = parseModels(txt)
                if (ids.isEmpty()) emptyList<String>() to "API ne koi model nahi bheja." else ids to null
            } else if (code == 401) emptyList<String>() to "API key galat ya expire hai (401)."
            else emptyList<String>() to "Error $code: ${errorDetail(txt)}"
        } catch (e: SocketTimeoutException) {
            emptyList<String>() to "Server ne time par jawab nahi diya."
        } catch (e: IOException) {
            emptyList<String>() to "Network problem: ${e.message}"
        }

    suspend fun ask(ctx: Context, history: List<Pair<String, String>>, maxTokens: Int = 1000, useMemory: Boolean = true): Ai =
        withContext(Dispatchers.IO) {
            val p = Prefs.get(ctx)
            if (p.apiKey.isBlank()) return@withContext Ai.Err("Settings mein Anthropic API key daalo.")
            if (!p.endpoint.startsWith("https://")) return@withContext Ai.Err("Endpoint https:// se shuru hona chahiye (Settings).")
            if (!Phone.online(ctx)) return@withContext Ai.Err(
                "Internet nahi hai, isliye cloud AI band hai. Notes, reminders, battery, flashlight jaise local commands chalte hain.")
            val query = history.lastOrNull { it.first == "user" }?.second ?: ""
            val req = AiRequest(p.endpoint, p.apiKey, p.model, systemPrompt(ctx, useMemory, query), history, maxTokens)
            execute(req, { m, u, h, b -> httpCall(m, u, h, b) })
        }

    /** Asks the API which model IDs this key can use. Returns (ids, errorMessage). */
    suspend fun listModels(ctx: Context): Pair<List<String>, String?> = withContext(Dispatchers.IO) {
        val p = Prefs.get(ctx)
        if (p.apiKey.isBlank()) return@withContext emptyList<String>() to "Pehle API key save karo."
        if (!p.endpoint.startsWith("https://")) return@withContext emptyList<String>() to "Endpoint https:// se shuru hona chahiye."
        if (!Phone.online(ctx)) return@withContext emptyList<String>() to "Internet nahi hai."
        fetchModels(p.endpoint, p.apiKey, { m, u, h, b -> httpCall(m, u, h, b) })
    }
}
