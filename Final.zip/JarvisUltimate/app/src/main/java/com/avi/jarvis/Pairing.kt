package com.avi.jarvis
import java.security.SecureRandom
import java.util.Random

data class Pairing(val id: String, val other: String, val status: String, val requestedByMe: Boolean, val codeId: String)

/** Pure (Android-free) pairing and credential rules so they can be unit-tested on the JVM. */
object PairingLogic {
    const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    const val CODE_LENGTH = 10
    const val CODE_TTL_MS = 10 * 60_000L
    const val ACCEPT_GRACE_MS = 15 * 60_000L          // must match firestore.rules (accept window after code expiry)
    const val PURGE_AFTER_MS = 2 * 24 * 60 * 60_000L  // Firestore TTL field `purgeAt`
    private val EMAIL = Regex("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")

    fun newCode(rnd: Random = SecureRandom()): String =
        buildString { repeat(CODE_LENGTH) { append(ALPHABET[rnd.nextInt(ALPHABET.length)]) } }

    fun normalize(raw: String): String = raw.trim().uppercase().filter { it in ALPHABET }
    fun isValid(code: String): Boolean = code.length == CODE_LENGTH && code.all { it in ALPHABET }
    fun codeExpired(expiresAtMs: Long, nowMs: Long): Boolean = expiresAtMs < nowMs
    fun acceptWindowOpen(expiresAtMs: Long, nowMs: Long): Boolean = nowMs <= expiresAtMs + ACCEPT_GRACE_MS

    /** Only the side that did NOT send the request may accept it. */
    fun canAccept(p: Pairing): Boolean = p.status == "pending" && !p.requestedByMe

    fun checkCreds(email: String, pass: String): String? = when {
        !EMAIL.matches(email.trim()) -> "Email sahi nahi hai."
        pass.length < 6 -> "Password kam se kam 6 characters ka rakho."
        else -> null
    }

    fun statusLabel(p: Pairing): String = when {
        p.status == "active" -> "Active (messaging abhi implement nahi hua)"
        p.requestedByMe -> "Pending: dusre phone par accept ka intezaar"
        else -> "Pending: ye phone accept kare"
    }
}
