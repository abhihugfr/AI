package com.avi.jarvis
import android.content.Context
import android.os.Build
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import java.util.Date

/**
 * Connected Mode foundation: Firebase email auth + one-time-code pairing with explicit accept + revoke.
 * Messaging / signals / location / FCM are NOT implemented yet (deliberately not built: the secure flow needs FCM + Cloud Functions + tested rules, see ARCHITECTURE.md).
 * Needs app/google-services.json from YOUR Firebase project and firestore.rules deployed.
 */
object Cloud {
    fun configured(ctx: Context): Boolean = FirebaseApp.getApps(ctx).isNotEmpty()
    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()
    val uid: String? get() = auth.currentUser?.uid
    val email: String? get() = auth.currentUser?.email

    /** Firestore/Auth tasks can hang forever when offline; give every call a deadline. */
    private suspend fun <T> Task<T>.limited(): T = withTimeout(15_000) { await() }

    fun friendly(e: Throwable): String = when (e) {
        is TimeoutCancellationException -> "Server se jawab nahi aaya. Internet check karo aur dobara try karo."
        is FirebaseNetworkException -> "Internet problem: network nahi mil raha."
        is FirebaseAuthException -> when (e.errorCode) {
            "ERROR_INVALID_EMAIL" -> "Email sahi nahi hai."
            "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL" -> "Email ya password galat hai."
            "ERROR_USER_NOT_FOUND" -> "Is email ka account nahi hai. Create account dabao."
            "ERROR_EMAIL_ALREADY_IN_USE" -> "Ye email pehle se registered hai. Login karo."
            "ERROR_WEAK_PASSWORD" -> "Password kam se kam 6 characters ka rakho."
            else -> e.message ?: "Login error"
        }
        is FirebaseFirestoreException -> when (e.code) {
            FirebaseFirestoreException.Code.PERMISSION_DENIED -> "Permission nahi mili (rules deploy hue? code galat ya expire?)."
            FirebaseFirestoreException.Code.UNAVAILABLE -> "Server tak nahi pahunch paya (internet?)."
            else -> e.message ?: "Database error"
        }
        else -> e.message ?: "Error"
    }

    private fun checkCreds(email: String, pass: String) {
        PairingLogic.checkCreds(email, pass)?.let { error(it) }
    }

    suspend fun signUp(email: String, pass: String) {
        checkCreds(email, pass)
        auth.createUserWithEmailAndPassword(email.trim(), pass).limited()
        saveProfile()
    }

    suspend fun signIn(email: String, pass: String) {
        checkCreds(email, pass)
        auth.signInWithEmailAndPassword(email.trim(), pass).limited()
        saveProfile()
    }

    fun signOut() = auth.signOut()

    private suspend fun saveProfile() {
        val me = uid ?: return
        db.collection("users").document(me).set(
            mapOf("email" to (email ?: ""), "device" to Build.MODEL, "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).limited()
    }

    /** 10 chars (~50 bits), valid 10 minutes, single use. `purgeAt` is the Firestore TTL field (cleanup after 2 days). */
    suspend fun createPairCode(): String {
        val me = uid ?: error("Pehle login karo.")
        val code = PairingLogic.newCode()
        val now = System.currentTimeMillis()
        db.collection("pairCodes").document(code).set(mapOf(
            "ownerUid" to me,
            "expiresAt" to Timestamp(Date(now + PairingLogic.CODE_TTL_MS)),
            "purgeAt" to Timestamp(Date(now + PairingLogic.PURGE_AFTER_MS)),
            "used" to false)).limited()
        return code
    }

    suspend fun joinWithCode(raw: String) {
        val me = uid ?: error("Pehle login karo.")
        val code = PairingLogic.normalize(raw)
        if (!PairingLogic.isValid(code)) error("Code ${PairingLogic.CODE_LENGTH} characters ka hota hai (A-Z aur 2-9).")
        val snap = db.collection("pairCodes").document(code).get().limited()
        if (!snap.exists()) error("Code galat hai ya expire ho gaya.")
        val owner = snap.getString("ownerUid") ?: error("Code invalid hai.")
        val exp = snap.getTimestamp("expiresAt")?.toDate()?.time ?: 0L
        if (snap.getBoolean("used") == true || PairingLogic.codeExpired(exp, System.currentTimeMillis())) error("Code expire ya use ho chuka hai.")
        if (owner == me) error("Apna hi code khud use nahi kar sakte.")
        db.collection("pairings").add(mapOf(
            "members" to listOf(owner, me), "requestedBy" to me, "status" to "pending",
            "codeId" to code, "createdAt" to FieldValue.serverTimestamp())).limited()
    }

    suspend fun pairings(): List<Pairing> {
        val me = uid ?: return emptyList()
        val q = db.collection("pairings").whereArrayContains("members", me).get().limited()
        return q.documents.mapNotNull { d ->
            val members = (d.get("members") as? List<*>)?.filterIsInstance<String>() ?: return@mapNotNull null
            Pairing(d.id, members.firstOrNull { it != me } ?: "?", d.getString("status") ?: "?",
                d.getString("requestedBy") == me, d.getString("codeId") ?: "")
        }.filter { it.status != "revoked" }
    }

    /**
     * Atomic accept: ONE batch flips pairing.status to active AND burns the code (used=true).
     * firestore.rules only allow the status change when getAfter(code).used == true and get(code).used == false,
     * so a code can activate at most one pairing and nothing can be accepted without burning it.
     * The accepter is always the code owner (rules force owner != requester), so the owner-only rule on pairCodes holds.
     */
    suspend fun accept(p: Pairing) {
        if (!PairingLogic.canAccept(p)) error("Ye request accept nahi ho sakti.")
        val batch = db.batch()
        batch.update(db.collection("pairings").document(p.id), "status", "active")
        batch.update(db.collection("pairCodes").document(p.codeId), "used", true)
        try { batch.commit().limited() } catch (e: FirebaseFirestoreException) {
            if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED || e.code == FirebaseFirestoreException.Code.NOT_FOUND)
                error("Accept nahi hua: request purani hai ya code pehle hi use ho chuka. Naya pairing code banao.")
            throw e
        }
    }

    suspend fun revoke(p: Pairing) {
        db.collection("pairings").document(p.id).update("status", "revoked").limited()
    }
}
