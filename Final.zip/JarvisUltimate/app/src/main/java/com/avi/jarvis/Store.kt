package com.avi.jarvis
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** extra: reminders = trigger time (ms); chat = 0 user / 1 assistant. */
data class Item(val id: Long, val text: String, val time: Long, val extra: Long = 0L)

/**
 * Encrypted list storage (memories, notes, reminders, chat). Data is a JSON string inside
 * EncryptedSharedPreferences. Old plain-text files from v0.2 (<name>.json) are migrated once and
 * only deleted after the encrypted copy was read back and verified. A corrupt payload is kept
 * under "json_corrupt" instead of being silently overwritten.
 */
class ListStore internal constructor(ctx: Context, private val name: String) {
    private val app = ctx.applicationContext
    private val lock = Any()
    private val sp: SharedPreferences by lazy { Secure.prefs(app, "store_$name") }
    private val legacy = File(app.filesDir, "$name.json")
    private var migrated = false

    private fun parse(s: String): MutableList<Item> {
        val a = JSONArray(s)
        return MutableList(a.length()) { i ->
            val o = a.getJSONObject(i)
            Item(o.getLong("id"), o.getString("text"), o.optLong("time"), o.optLong("extra"))
        }
    }

    private fun toJson(l: List<Item>): String {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("text", it.text).put("time", it.time).put("extra", it.extra)) }
        return a.toString()
    }

    private fun write(l: List<Item>) { sp.edit().putString("json", toJson(l)).putInt("v", 2).commit() }

    private fun migrate() {
        if (migrated) return
        migrated = true
        if (!legacy.exists()) return
        try {
            if (sp.getString("json", null) != null) return   // already have encrypted data: leave legacy file alone
            val list = parse(legacy.readText())
            write(list)
            val back = sp.getString("json", null)
            if (back != null && parse(back).size == list.size) legacy.delete()
        } catch (e: Exception) { /* keep legacy file untouched, nothing lost */ }
    }

    private fun read(): MutableList<Item> {
        migrate()
        val s = try { sp.getString("json", null) } catch (e: Exception) { null } ?: return mutableListOf()
        return try { parse(s) } catch (e: Exception) {
            sp.edit().putString("json_corrupt", s).commit()
            mutableListOf()
        }
    }

    fun all(): List<Item> = synchronized(lock) { read() }

    fun add(text: String, extra: Long = 0L, keep: Int = 1000): Item = synchronized(lock) {
        val l = read()
        val id = maxOf(System.currentTimeMillis(), (l.maxOfOrNull { it.id } ?: 0L) + 1)
        val item = Item(id, text, System.currentTimeMillis(), extra)
        l.add(item)
        write(if (l.size > keep) l.takeLast(keep) else l)
        item
    }

    fun update(id: Long, text: String) = synchronized(lock) {
        write(read().map { if (it.id == id) it.copy(text = text) else it })
    }

    fun remove(id: Long) = synchronized(lock) { write(read().filter { it.id != id }) }
    fun clear() = synchronized(lock) { write(emptyList()) }
}

object Stores {
    private val cache = ConcurrentHashMap<String, ListStore>()
    fun get(ctx: Context, name: String): ListStore = cache.getOrPut(name) { ListStore(ctx, name) }
}
