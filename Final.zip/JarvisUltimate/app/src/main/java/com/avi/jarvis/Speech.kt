package com.avi.jarvis
import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object Speech {
    fun say(ctx: Context, tts: TextToSpeech?, text: String, utteranceId: String = "jarvis"): Boolean {
        if (tts == null) return false
        val loc = if (text.any { it in '\u0900'..'\u097F' }) Locale("hi", "IN") else Locale("en", "IN")
        val r = tts.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.getDefault())
        tts.setSpeechRate(Prefs.get(ctx).rate)
        return tts.speak(text.take(500), TextToSpeech.QUEUE_FLUSH, null, utteranceId) == TextToSpeech.SUCCESS
    }
}
