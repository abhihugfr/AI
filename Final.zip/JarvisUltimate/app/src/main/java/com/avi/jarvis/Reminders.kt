package com.avi.jarvis
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object Notifs {
    const val CH_REM = "reminders"
    const val CH_WAKE = "wake"
    fun ensure(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_REM, "Reminders", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, "Wake word (mic on)", NotificationManager.IMPORTANCE_LOW))
    }
    fun reminder(ctx: Context, text: String, id: Int) {
        ensure(ctx)
        val n = NotificationCompat.Builder(ctx, CH_REM)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("JARVIS reminder").setContentText(text)
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { /* notification permission denied */ }
    }
}

class ReminderWorker(ctx: Context, p: WorkerParameters) : Worker(ctx, p) {
    override fun doWork(): Result {
        val text = inputData.getString("t") ?: "Reminder"
        val id = inputData.getLong("id", -1L)
        Notifs.reminder(applicationContext, text, 2000 + (id % 1000).toInt())
        if (id >= 0) Stores.get(applicationContext, "reminders").remove(id)
        return Result.success()
    }
}

/** Reminders use WorkManager: survive reboot, but Android may delay them a few minutes in Doze (not exact alarms). */
object Reminders {
    private val REL = Regex("(\\d+)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?|ghant[ae]y?|days?|din)")
    private const val MAX_AHEAD_MS = 366L * 86_400_000L
    private val ABS = Regex("(?:at\\s*)?(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|baje)")

    fun fmt(ms: Long): String = SimpleDateFormat("d MMM, hh:mm a", Locale.getDefault()).format(Date(ms))

    fun schedule(ctx: Context, text: String, at: Long): Item {
        val item = Stores.get(ctx, "reminders").add(text, at)
        val delay = maxOf(0L, at - System.currentTimeMillis())
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("id" to item.id, "t" to text)).build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("rem_${item.id}", ExistingWorkPolicy.REPLACE, req)
        return item
    }

    fun cancel(ctx: Context, id: Long) {
        WorkManager.getInstance(ctx).cancelUniqueWork("rem_$id")
        Stores.get(ctx, "reminders").remove(id)
    }

    /** "10 minute baad chai", "in 2 hours call mom", "at 8 pm gym", "7 baje padhai". Returns (triggerAt, task). */
    fun parse(raw: String, now: Long = System.currentTimeMillis()): Pair<Long, String>? {
        val t = raw.lowercase()
        val at: Long
        val matched: String
        val rel = REL.find(t)
        if (rel != null) {
            val n = rel.groupValues[1].toLongOrNull() ?: return null
            if (n > 100_000L) return null
            val u = rel.groupValues[2]
            val ms = when {
                u.startsWith("sec") -> n * 1000
                u.startsWith("min") -> n * 60_000
                u.startsWith("h") || u.startsWith("ghant") -> n * 3_600_000
                else -> n * 86_400_000
            }
            if (ms > MAX_AHEAD_MS) return null
            at = now + ms; matched = rel.value
        } else {
            val ab = ABS.find(t) ?: return null
            val hh0 = ab.groupValues[1].toInt()
            val mm = ab.groupValues[2].ifBlank { "0" }.toInt()
            val s = ab.groupValues[3]
            var hh = hh0
            if (s == "pm" && hh < 12) hh += 12
            if (s == "am" && hh == 12) hh = 0
            if (hh > 23 || mm > 59) return null
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hh); set(Calendar.MINUTE, mm); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis <= now && s == "baje" && hh < 12) cal.add(Calendar.HOUR_OF_DAY, 12)
            if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
            at = cal.timeInMillis; matched = ab.value
        }
        var task = raw.replace(Regex(Regex.escape(matched), RegexOption.IGNORE_CASE), " ").trim()
        task = task.replace(Regex("(?i)^((please|remind me|remind|reminder|set a reminder|set reminder|yaad dilao|yaad dilana|yaad dila|mujhe|in|at|baad|mein|to|ko|about|that)\\b[\\s,:-]*)+"), "")
        task = task.replace(Regex("(?i)([\\s,]*(yaad dilao|yaad dilana|yaad dila do|yaad dila|remind me|baad|mein|please))+$"), "").trim()
        return at to task.ifBlank { "Reminder" }
    }
}
