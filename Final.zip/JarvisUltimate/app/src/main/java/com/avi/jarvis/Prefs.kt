package com.avi.jarvis
import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Keystore-backed encryption helpers shared by Prefs and Store. */
object Secure {
    /** true when Keystore encryption failed twice and a private plain file is used instead (shown in Settings > About). */
    @Volatile var degraded = false

    fun masterKey(c: Context): MasterKey = MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()

    fun prefs(c: Context, name: String): SharedPreferences {
        val app = c.applicationContext
        fun make(): SharedPreferences = EncryptedSharedPreferences.create(
            app, name, masterKey(app),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
        return try { make() } catch (e: Exception) {
            // Keystore reset (device restore / OS bug): the old ciphertext can never be decrypted again.
            app.deleteSharedPreferences(name)
            try { make() } catch (e2: Exception) { degraded = true; app.getSharedPreferences(name + "_plain", Context.MODE_PRIVATE) }
        }
    }
}

/** Settings. The API key lives only in encrypted on-device storage; it is never in the APK or the repo. */
class Prefs private constructor(private val sp: SharedPreferences) {
    var apiKey: String
        get() = sp.getString("key", "") ?: ""
        set(v) { sp.edit().putString("key", v).apply() }
    var model: String
        get() = sp.getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5"
        set(v) { sp.edit().putString("model", v).apply() }
    var endpoint: String
        get() = sp.getString("endpoint", DEFAULT_ENDPOINT) ?: DEFAULT_ENDPOINT
        set(v) { sp.edit().putString("endpoint", v).apply() }
    var persona: String
        get() = sp.getString("persona", DEFAULT_PERSONA) ?: DEFAULT_PERSONA
        set(v) { sp.edit().putString("persona", v).apply() }
    var rate: Float
        get() = sp.getFloat("rate", 1f)
        set(v) { sp.edit().putFloat("rate", v).apply() }

    companion object {
        const val DEFAULT_ENDPOINT = "https://api.anthropic.com/v1/messages"
        const val DEFAULT_PERSONA = "You are JARVIS, the owner's private assistant. Reply briefly, in the language the owner uses (Hindi, English or Hinglish)."
        @Volatile private var inst: Prefs? = null

        fun get(ctx: Context): Prefs = inst ?: synchronized(this) {
            inst ?: Prefs(Secure.prefs(ctx, "jarvis_secure")).also { inst = it }
        }
    }
}
