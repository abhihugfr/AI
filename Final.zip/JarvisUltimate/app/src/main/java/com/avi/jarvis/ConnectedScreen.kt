package com.avi.jarvis
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.launch

@Composable
fun ConnectedScreen() {
    val ctx = LocalContext.current
    if (!Cloud.configured(ctx)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Connected Mode", color = Cyan, fontSize = 20.sp)
            Glass(Modifier.fillMaxWidth()) {
                Text("Firebase abhi set nahi hai.", color = Color.White)
                Text("1) Firebase console mein apna private project banao\n2) Android app add karo, package: com.avi.jarvis\n3) google-services.json ko app/ folder mein rakho\n4) Authentication mein Email/Password on karo\n5) Firestore banao aur firestore.rules paste karke Publish karo\n6) App dobara build karo\n\nPoori guide: SETUP_FIREBASE.md", color = Color.White)
            }
        }
        return
    }
    val scope = rememberCoroutineScope()
    var uid by remember { mutableStateOf(Cloud.uid) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var myCode by remember { mutableStateOf("") }
    var joinCode by remember { mutableStateOf("") }
    val pairs = remember { mutableStateListOf<Pairing>() }

    fun op(block: suspend () -> Unit) {
        scope.launch {
            busy = true; msg = ""
            try { block() } catch (e: TimeoutCancellationException) { msg = Cloud.friendly(e) } catch (e: CancellationException) { throw e } catch (e: Exception) { msg = Cloud.friendly(e) }
            busy = false
        }
    }
    suspend fun refresh() { val l = Cloud.pairings(); pairs.clear(); pairs.addAll(l) }
    LaunchedEffect(uid) { if (uid != null) try { refresh() } catch (e: Exception) { msg = Cloud.friendly(e) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Connected Mode", color = Cyan, fontSize = 20.sp)
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cyan)
        if (msg.isNotBlank()) Text(msg, color = ErrRed)
        if (uid == null) {
            OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") }, singleLine = true)
            OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), label = { Text("Password (min 6)") },
                visualTransformation = PasswordVisualTransformation(), singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy, onClick = { op { Cloud.signIn(email, pass); uid = Cloud.uid } }) { Text("Login") }
                OutlinedButton(enabled = !busy, onClick = { op { Cloud.signUp(email, pass); uid = Cloud.uid } }) { Text("Create account") }
            }
        } else {
            Text("Logged in: ${Cloud.email ?: uid}", color = Color.White)
            Glass(Modifier.fillMaxWidth()) {
                Text("Pair a device", color = Cyan, fontSize = 12.sp)
                Text("Is phone par code banao, dusre phone par wahi code daalo. Code 10 minute ka aur ek baar ka hai.", color = Color.White, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Button(enabled = !busy, onClick = { op { myCode = Cloud.createPairCode() } }) { Text("Create pairing code") }
                if (myCode.isNotBlank()) Text("Code: $myCode", color = Cyan, fontSize = 22.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(joinCode, { joinCode = it }, Modifier.fillMaxWidth(), label = { Text("Dusre phone ka code") }, singleLine = true)
                OutlinedButton(enabled = !busy && joinCode.isNotBlank(), onClick = {
                    op { Cloud.joinWithCode(joinCode); joinCode = ""; refresh(); msg = "Request bhej di. Dusre phone par accept hona baaki hai." }
                }) { Text("Send pairing request") }
            }
            Text("Pairings", color = Cyan, fontSize = 16.sp)
            if (pairs.isEmpty()) Text("Koi pairing nahi.", color = Color.White)
            pairs.forEach { p ->
                Glass(Modifier.fillMaxWidth()) {
                    Text("Device: ${p.other.take(8)}...", color = Color.White)
                    Text(PairingLogic.statusLabel(p), color = Cyan, fontSize = 12.sp)
                    Row {
                        if (PairingLogic.canAccept(p))
                            TextButton(enabled = !busy, onClick = { op { Cloud.accept(p); refresh() } }) { Text("Accept") }
                        TextButton(enabled = !busy, onClick = { op { Cloud.revoke(p); refresh() } }) {
                            Text(if (p.status == "active") "Revoke" else "Reject")
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = !busy, onClick = { op { refresh() } }) { Text("Refresh") }
                OutlinedButton(onClick = { Cloud.signOut(); uid = null; pairs.clear(); myCode = "" }) { Text("Logout") }
            }
        }
    }
}
