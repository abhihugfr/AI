package com.avi.jarvis
import android.content.Context
import android.view.KeyEvent
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Commands {
    /** Local command first; otherwise cloud AI. bg=true means called from the wake-word service (no UI launches allowed). */
    suspend fun process(ctx: Context, text: String, history: List<Pair<String, String>> = emptyList(), bg: Boolean = false): Ai {
        handle(ctx, text, bg)?.let { return Ai.Ok(it) }
        return Brain.ask(ctx, history + ("user" to text))
    }

    /** Words that mean "explain/advise", so a sentence like "battery kaise bachaye" goes to the AI, not the battery command. */
    private val EXPLAIN = listOf("kaise", "how ", "why ", "kyun", "kyu ", "tips", "explain", "samjhao", "kya hota", "what is")

    fun handle(ctx: Context, raw: String, bg: Boolean): String? {
        val t = raw.lowercase().trim().trimEnd('.', '!', '?')
        fun has(vararg k: String) = k.any { it in t }
        val cmd = t.split(Regex("\\s+")).size <= 6 && EXPLAIN.none { it in t }
        val openCmd = cmd && (t.startsWith("open ") || t.startsWith("kholo ") || t.endsWith(" kholo"))
        val ui = "Ye kaam app khuli/unlocked hone par hi ho sakta hai (Android background limit). App khol ke bolo."
        val notes = Stores.get(ctx, "notes")
        val mem = Stores.get(ctx, "memories")

        return when {
            has("remind", "yaad dila") -> {
                val p = Reminders.parse(raw)
                if (p != null) {
                    val it2 = Reminders.schedule(ctx, p.second, p.first)
                    val warn = if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) ""
                    else "\nWarning: JARVIS ke notifications band hain, reminder dikhega nahi. Settings > Permissions se allow karo."
                    "Theek hai, ${Reminders.fmt(it2.extra)} par yaad dilaunga: ${p.second}$warn"
                } else if (t.startsWith("remind") || t.startsWith("yaad dila"))
                    "Time samajh nahi aaya. Aise bolo: '10 minute baad chai yaad dilao' ya 'remind me at 8 pm to call'."
                else null
            }
            has("yaad rakh", "remember that", "remember this") || t.startsWith("remember ") -> {
                val m = raw.replace(Regex("(?i)\\b(please|yaad rakhna|yaad rakho|yaad rakh|remember that|remember this|remember)\\b[:,]?"), " ").trim()
                if (m.isBlank()) "Kya yaad rakhoon?" else { mem.add(m); "Yaad rakh liya: $m" }
            }
            t.startsWith("note ") || t.startsWith("note:") -> {
                val n = raw.replace(Regex("(?i)^\\s*note( karo| kar lo)?\\s*[:,-]?\\s*(that\\s+)?"), "").trim()
                if (n.isBlank()) "Note mein kya likhoon?" else { notes.add(n); "Note save kar diya: $n" }
            }
            cmd && has("show notes", "mere notes", "notes dikhao", "my notes") -> {
                val l = notes.all().takeLast(5)
                if (l.isEmpty()) "Abhi koi note nahi hai." else "Aakhri notes:\n" + l.joinToString("\n") { "- " + it.text }
            }
            cmd && has("meri memories", "what do you remember", "kya yaad hai") -> {
                val l = mem.all().takeLast(5)
                if (l.isEmpty()) "Abhi kuch yaad rakhne ko nahi diya." else "Mujhe ye yaad hai:\n" + l.joinToString("\n") { "- " + it.text }
            }
            cmd && has("battery") -> Phone.battery(ctx)
            cmd && has("flashlight", "torch") -> Phone.torch(ctx, !has(" off", "band", "bund"))
            cmd && has("network status", "internet status", "wifi status", "net status", "online hoon") -> Phone.network(ctx)
            cmd && has("device info", "phone info") -> Phone.deviceInfo()
            cmd && has("what time", "time kya", "kitne baje", "current time", "samay kya") ->
                SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            cmd && has("today's date", "what date", "aaj ki date", "tarikh kya", "date kya") ->
                SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
            cmd && has("volume up", "volume badha", "volume increase", "awaaz badha") -> Phone.volume(ctx, 1)
            cmd && has("volume down", "volume kam", "volume decrease", "awaaz kam") -> Phone.volume(ctx, -1)
            cmd && (t == "mute" || has("mute karo")) -> Phone.mute(ctx)
            cmd && has("play music", "music chalao", "gana chalao", "resume music") -> Phone.media(ctx, KeyEvent.KEYCODE_MEDIA_PLAY, "Play bheja")
            cmd && has("pause music", "music roko", "gana roko", "pause song") -> Phone.media(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE, "Pause bheja")
            cmd && has("next song", "agla gana", "next track") -> Phone.media(ctx, KeyEvent.KEYCODE_MEDIA_NEXT, "Next bheja")
            cmd && has("previous song", "pichla gana", "previous track") -> Phone.media(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Previous bheja")
            cmd && (openCmd || has("settings")) && Phone.settingsAction(t) != null ->
                if (bg) ui else Phone.openSettings(ctx, t)
            t.startsWith("share text ") || t.startsWith("share:") ->
                if (bg) ui else Phone.share(ctx, raw.trim().substring(if (t.startsWith("share:")) 6 else 11).trim())
            cmd && has("alarm") -> {
                val r = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").find(t)
                if (r == null) null else {
                    var h = r.groupValues[1].toInt()
                    val m = r.groupValues[2].ifBlank { "0" }.toInt()
                    val ap = r.groupValues[3]
                    if (ap == "pm" && h < 12) h += 12
                    if (ap == "am" && h == 12) h = 0
                    if (h !in 0..23 || m !in 0..59) null else if (bg) ui else Phone.alarm(ctx, h, m)
                }
            }
            openCmd -> {
                if (bg) ui else Phone.openApp(ctx, t.removePrefix("open ").removePrefix("kholo ").removeSuffix(" kholo").trim())
            }
            else -> null
        }
    }
}
