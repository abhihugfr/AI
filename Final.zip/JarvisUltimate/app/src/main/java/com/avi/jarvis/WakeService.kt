package com.avi.jarvis
import android.Manifest
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

object WakeState { var running by mutableStateOf(false) }

/**
 * Foreground "listen for JARVIS" service. Honest limits:
 *  - It loops Android's SpeechRecognizer (not a true low-power wake-word engine). Battery cost is real.
 *  - Recognizer may beep between loops and may use Google's servers on some devices (we prefer offline).
 *  - Only text containing the wake word is acted on; other speech is discarded, never stored.
 *  - Android blocks launching apps/screens from here; such commands answer with an explanation.
 */
class WakeService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var awaitingCommand = false
    private var stopped = false
    private var afterSpeak: (() -> Unit)? = null
    private var errorStreak = 0
    private var ttsReady = false
    private val speakWatchdog = Runnable { finishSpeak() }
    private var lastActive = SystemClock.elapsedRealtime()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        try { startFg() } catch (e: Exception) {
            Toast.makeText(this, "Mic service start nahi ho payi (mic permission?).", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        if (!granted(this, Manifest.permission.RECORD_AUDIO)) {
            Toast.makeText(this, "Mic permission chahiye.", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone mein speech recognizer nahi hai.", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        if (tts == null) {
            tts = TextToSpeech(this) { st -> ttsReady = st == TextToSpeech.SUCCESS }.also { t ->
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { finishSpeak() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { finishSpeak() } }
                })
            }
        }
        WakeState.running = true
        listen()
        return START_NOT_STICKY
    }

    private fun startFg() {
        Notifs.ensure(this)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, Notifs.CH_WAKE)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS mic ON")
            .setContentText("'JARVIS' bolo. Band karne ke liye Stop dabao.")
            .setOngoing(true).setContentIntent(open).addAction(0, "Stop", stop).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun listen() {
        if (stopped) return
        if (SystemClock.elapsedRealtime() - lastActive > IDLE_LIMIT_MS) {
            Toast.makeText(this, "JARVIS mic 30 min se idle tha, battery bachane ke liye band kiya.", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                if (stopped) return
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
                awaitingCommand = false
                val quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                if (quiet) { errorStreak = 0; main.postDelayed({ listen() }, 300L); return }
                errorStreak++
                if (errorStreak > MAX_HARD_ERRORS) {
                    Toast.makeText(this@WakeService, "Speech recognizer baar baar fail hua, wake word band kiya.", Toast.LENGTH_LONG).show()
                    stopSelf(); return
                }
                val wait = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 2000L else minOf(1000L shl errorStreak, 15000L)
                main.postDelayed({ listen() }, wait)
            }
            override fun onResults(results: Bundle?) {
                if (stopped) return
                errorStreak = 0
                val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                if (awaitingCommand) {
                    awaitingCommand = false
                    if (heard.isBlank()) listen() else respond(heard)
                    return
                }
                val low = heard.lowercase()
                val end = WAKE.firstNotNullOfOrNull { w -> low.indexOf(w).takeIf { it >= 0 }?.plus(w.length) }
                if (end == null) { listen(); return }
                lastActive = SystemClock.elapsedRealtime()
                val cmd = heard.substring(minOf(end, heard.length)).trim(' ', ',', '.', '!')
                if (cmd.isBlank()) {
                    awaitingCommand = true
                    say("Ji?") { listen() }
                } else respond(cmd)
            }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3))
    }

    private fun respond(text: String) {
        scope.launch {
            val reply = when (val r = Commands.process(this@WakeService, text, emptyList(), bg = true)) {
                is Ai.Ok -> r.text
                is Ai.Err -> r.msg
            }
            say(reply) { listen() }
        }
    }

    /** Runs the pending "after speaking" action exactly once (listening must always resume, or the service goes deaf). */
    private fun finishSpeak() {
        main.removeCallbacks(speakWatchdog)
        val next = afterSpeak
        afterSpeak = null
        next?.invoke()
    }

    private fun say(text: String, then: () -> Unit) {
        val t = tts
        if (t == null || !ttsReady) { then(); return }
        afterSpeak = then
        if (!Speech.say(this, t, text)) { finishSpeak(); return }
        main.postDelayed(speakWatchdog, SPEAK_TIMEOUT_MS)   // if no callback ever arrives, resume listening anyway
    }

    override fun onDestroy() {
        stopped = true
        main.removeCallbacksAndMessages(null)
        sr?.destroy(); sr = null
        tts?.stop(); tts?.shutdown(); tts = null
        scope.cancel()
        WakeState.running = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.avi.jarvis.STOP"
        private const val MAX_HARD_ERRORS = 8
        private const val SPEAK_TIMEOUT_MS = 20_000L
        private const val IDLE_LIMIT_MS = 30 * 60 * 1000L
        val WAKE = listOf("jarvis", "jarvish", "jarwis", "जार्विस", "जारविस", "जार्विश", "जर्विस")

        fun start(ctx: Context): Boolean = if (!granted(ctx, Manifest.permission.RECORD_AUDIO)) false else try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java)); true
        } catch (e: Exception) { false }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeService::class.java)) }
    }
}
