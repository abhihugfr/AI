package com.avi.jarvis
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent

object Phone {
    fun battery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra("level", -1) ?: -1
        val s = i?.getIntExtra("scale", 100) ?: 100
        val ch = i?.getIntExtra("status", -1) == BatteryManager.BATTERY_STATUS_CHARGING
        return "Battery ${if (l < 0 || s <= 0) 0 else l * 100 / s}%" + if (ch) " (charging)" else ""
    }

    fun online(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun network(ctx: Context): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) } ?: return "Offline: koi network nahi."
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi connected."
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data connected."
            else -> "Network connected."
        }
    }

    fun deviceInfo(): String =
        "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

    fun torch(ctx: Context, on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Is phone mein flashlight nahi mili."
        cm.setTorchMode(id, on)
        if (on) "Flashlight on." else "Flashlight off."
    } catch (e: Exception) { "Flashlight error: ${e.message}" }

    fun volume(ctx: Context, dir: Int): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
            if (dir > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        return if (dir > 0) "Volume badha diya." else "Volume kam kar diya."
    }

    fun mute(ctx: Context): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
        return "Media volume mute."
    }

    fun media(ctx: Context, keyCode: Int, label: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
        return "$label (kaam tabhi karega jab koi music/video app active ho)."
    }

    private fun launch(ctx: Context, i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val m = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
            ?: return "'$name' naam ka app nahi mila."
        val l = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "App open nahi ho paya."
        return if (launch(ctx, l)) "${m.loadLabel(pm)} khol diya." else "App open nahi ho paya."
    }

    fun alarm(ctx: Context, h: Int, m: Int): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS")
        return if (launch(ctx, i)) "Alarm %02d:%02d ke liye clock app khol diya, confirm kar lo.".format(h, m)
        else "Clock app nahi mila."
    }

    fun settingsAction(t: String): String? = when {
        "wifi" in t || "wi-fi" in t -> Settings.ACTION_WIFI_SETTINGS
        "bluetooth" in t -> Settings.ACTION_BLUETOOTH_SETTINGS
        "display" in t || "brightness" in t -> Settings.ACTION_DISPLAY_SETTINGS
        "sound" in t -> Settings.ACTION_SOUND_SETTINGS
        "location" in t -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
        "airplane" in t -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
        "settings" in t -> Settings.ACTION_SETTINGS
        else -> null
    }

    fun openSettings(ctx: Context, t: String): String {
        val a = settingsAction(t) ?: return "Kaun si setting?"
        return if (launch(ctx, Intent(a))) "Settings khol di." else "Ye setting is phone par nahi khuli."
    }

    fun share(ctx: Context, text: String): String {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        return if (launch(ctx, Intent.createChooser(send, "JARVIS share"))) "Share sheet khol di." else "Share nahi ho paya."
    }
}
