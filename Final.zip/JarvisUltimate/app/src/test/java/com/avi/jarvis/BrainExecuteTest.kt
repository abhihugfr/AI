package com.avi.jarvis
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException
import java.net.SocketTimeoutException

/** Retry / error-mapping policy of the AI call, driven by a scripted fake transport (no network, no real sleeping). */
class BrainExecuteTest {
    private val ok = """{"content":[{"type":"text","text":"hello"}]}"""
    private fun req(history: List<Pair<String, String>> = listOf("user" to "hi")) =
        AiRequest("https://api.example.com/v1/messages", "sk-ant-test-key-1234567890", "claude-sonnet-5-5", "SYS PROMPT", history, 100)

    /** script items: Pair<Int,String> = HTTP reply, Throwable = thrown by the transport. Last item repeats. */
    @Suppress("UNCHECKED_CAST")
    private class Fake(private val script: List<Any>) {
        var calls = 0
        var lastUrl = ""; var lastMethod = ""; var lastBody: String? = null
        var lastHeaders: Map<String, String> = emptyMap()
        val sleeps = mutableListOf<Long>()
        val transport: Transport = { m, u, h, b ->
            lastMethod = m; lastUrl = u; lastHeaders = h; lastBody = b
            val x = script[minOf(calls, script.size - 1)]
            calls++
            if (x is Throwable) throw x
            x as Pair<Int, String>
        }
    }

    @Test fun successParsesText() = runTest {
        val f = Fake(listOf(200 to ok))
        assertEquals(Ai.Ok("hello"), Brain.execute(req(), f.transport) { f.sleeps.add(it) })
        assertEquals(1, f.calls); assertTrue(f.sleeps.isEmpty())
    }

    @Test fun requestShapeAndKeyOnlyInHeader() = runTest {
        val f = Fake(listOf(200 to ok))
        Brain.execute(req(listOf("user" to "namaste")), f.transport) { }
        val body = JSONObject(f.lastBody!!)
        assertEquals("claude-sonnet-5-5", body.getString("model"))
        assertEquals("SYS PROMPT", body.getString("system"))
        assertEquals(100, body.getInt("max_tokens"))
        assertEquals("namaste", body.getJSONArray("messages").getJSONObject(0).getString("content"))
        assertFalse(f.lastBody!!.contains("sk-ant-test-key"))
        assertEquals("sk-ant-test-key-1234567890", f.lastHeaders["x-api-key"])
        assertEquals("2023-06-01", f.lastHeaders["anthropic-version"])
        assertEquals("POST", f.lastMethod)
    }

    @Test fun unauthorizedIsNotRetried() = runTest {
        val f = Fake(listOf(401 to """{"error":{"message":"invalid x-api-key"}}"""))
        val r = Brain.execute(req(), f.transport) { f.sleeps.add(it) }
        assertTrue(r is Ai.Err && r.msg.contains("401"))
        assertEquals(1, f.calls); assertTrue(f.sleeps.isEmpty())
    }

    @Test fun clientErrorsAreNotRetriedAndShowDetail() = runTest {
        for ((code, needle) in listOf(400 to "400", 403 to "403", 404 to "404", 418 to "418")) {
            val f = Fake(listOf(code to """{"error":{"message":"detail-$code"}}"""))
            val r = Brain.execute(req(), f.transport) { }
            assertTrue("code $code", r is Ai.Err && r.msg.contains(needle))
            assertEquals(1, f.calls)
        }
        val f = Fake(listOf(400 to """{"error":{"message":"max_tokens too big"}}"""))
        assertTrue((Brain.execute(req(), f.transport) { } as Ai.Err).msg.contains("max_tokens too big"))
        val nf = Fake(listOf(404 to """{"error":{"message":"model: x"}}"""))
        assertTrue((Brain.execute(req(), nf.transport) { } as Ai.Err).msg.contains("claude-sonnet-5-5"))
    }

    @Test fun rateLimitThenSuccessRetriesWithBackoff() = runTest {
        val f = Fake(listOf(429 to "{}", 429 to "{}", 200 to ok))
        assertEquals(Ai.Ok("hello"), Brain.execute(req(), f.transport) { f.sleeps.add(it) })
        assertEquals(3, f.calls)
        assertEquals(listOf(1000L, 2000L), f.sleeps)
    }

    @Test fun persistentServerErrorStopsAfterFourAttempts() = runTest {
        for (code in listOf(500, 502, 503, 504, 529)) {
            val f = Fake(listOf(code to """{"error":{"message":"overloaded"}}"""))
            val r = Brain.execute(req(), f.transport) { f.sleeps.add(it) }
            assertTrue(r is Ai.Err && r.msg.contains("Server busy ($code)"))
            assertEquals(Brain.MAX_ATTEMPTS, f.calls)
            assertEquals(listOf(1000L, 2000L, 4000L), f.sleeps)
        }
    }

    @Test fun timeoutIsRetriedThenReported() = runTest {
        val f = Fake(listOf(SocketTimeoutException("read timed out")))
        val r = Brain.execute(req(), f.transport) { f.sleeps.add(it) }
        assertTrue(r is Ai.Err && r.msg.contains("time par jawab nahi"))
        assertEquals(Brain.MAX_ATTEMPTS, f.calls)
    }

    @Test fun timeoutThenSuccessRecovers() = runTest {
        val f = Fake(listOf(SocketTimeoutException("x"), 200 to ok))
        assertEquals(Ai.Ok("hello"), Brain.execute(req(), f.transport) { })
        assertEquals(2, f.calls)
    }

    @Test fun ioErrorIsReported() = runTest {
        val f = Fake(listOf(IOException("Unable to resolve host")))
        val r = Brain.execute(req(), f.transport) { }
        assertTrue(r is Ai.Err && r.msg.contains("Unable to resolve host"))
    }

    @Test fun cancellationPropagatesAndIsNotRetried() = runTest {
        val f = Fake(listOf(CancellationException("stopped by user")))
        var thrown: Throwable? = null
        try { Brain.execute(req(), f.transport) { } } catch (e: CancellationException) { thrown = e }
        assertNotNull(thrown)
        assertEquals(1, f.calls)
    }

    @Test fun malformedSuccessBodyIsAnError() = runTest {
        val f = Fake(listOf(200 to "<html>proxy login</html>"))
        assertTrue(Brain.execute(req(), f.transport) { } is Ai.Err)
    }

    // ---- model discovery ----
    @Test fun modelDiscoverySuccess() = runTest {
        val f = Fake(listOf(200 to """{"data":[{"id":"claude-sonnet-5-5"},{"id":"claude-haiku-5-5"}]}"""))
        val (ids, err) = Brain.fetchModels("https://api.anthropic.com/v1/messages", "sk-ant-x", f.transport)
        assertEquals(listOf("claude-sonnet-5-5", "claude-haiku-5-5"), ids)
        assertEquals(null, err)
        assertEquals("GET", f.lastMethod)
        assertEquals("https://api.anthropic.com/v1/models?limit=50", f.lastUrl)
        assertEquals("sk-ant-x", f.lastHeaders["x-api-key"])
        assertEquals(null, f.lastBody)
    }

    @Test fun modelDiscoveryErrors() = runTest {
        val unauthorized = Brain.fetchModels("https://a/v1/messages", "k", Fake(listOf(401 to "{}")).transport)
        assertTrue(unauthorized.first.isEmpty() && unauthorized.second!!.contains("401"))
        val server = Brain.fetchModels("https://a/v1/messages", "k", Fake(listOf(500 to """{"error":{"message":"boom"}}""")).transport)
        assertTrue(server.second!!.contains("500") && server.second!!.contains("boom"))
        val empty = Brain.fetchModels("https://a/v1/messages", "k", Fake(listOf(200 to """{"data":[]}""")).transport)
        assertTrue(empty.first.isEmpty() && empty.second != null)
        val timeout = Brain.fetchModels("https://a/v1/messages", "k", Fake(listOf(SocketTimeoutException("t"))).transport)
        assertTrue(timeout.second!!.contains("time par jawab nahi"))
        val io = Brain.fetchModels("https://a/v1/messages", "k", Fake(listOf(IOException("down"))).transport)
        assertTrue(io.second!!.contains("down"))
    }

    @Test fun timeoutConstants() {
        assertEquals(15_000, Brain.CONNECT_MS)
        assertEquals(60_000, Brain.READ_MS)
        assertEquals(4, Brain.MAX_ATTEMPTS)
    }
}
