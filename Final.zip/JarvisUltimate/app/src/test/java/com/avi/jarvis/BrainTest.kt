package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BrainTest {
    @Test fun parsesTextBlocks() {
        val r = Brain.parseResponse("""{"content":[{"type":"text","text":"Namaste"},{"type":"text","text":" Avi"}]}""")
        assertEquals(Ai.Ok("Namaste Avi"), r)
    }

    @Test fun emptyContentIsError() {
        assertTrue(Brain.parseResponse("""{"content":[]}""") is Ai.Err)
    }

    @Test fun malformedJsonIsError() {
        assertTrue(Brain.parseResponse("not json") is Ai.Err)
    }

    @Test fun errorDetailReadsApiMessage() {
        assertEquals("bad key", Brain.errorDetail("""{"type":"error","error":{"type":"authentication_error","message":"bad key"}}"""))
    }

    @Test fun parsesModelList() {
        assertEquals(listOf("a", "b"), Brain.parseModels("""{"data":[{"id":"a"},{"id":"b"}]}"""))
    }

    @Test fun backoffIsExponentialAndCapped() {
        assertEquals(1000L, Brain.backoffMs(0))
        assertEquals(2000L, Brain.backoffMs(1))
        assertEquals(4000L, Brain.backoffMs(2))
        assertEquals(8000L, Brain.backoffMs(5))
    }

    @Test fun keyValidation() {
        assertTrue(Brain.validKey("sk-ant-api03-abcdefghijklmnop"))
        assertFalse(Brain.validKey("hello"))
        assertFalse(Brain.validKey("sk-ant-"))
    }

    @Test fun modelsUrlFromEndpoint() {
        assertEquals("https://api.anthropic.com/v1/models", Brain.modelsUrl("https://api.anthropic.com/v1/messages"))
    }

    @Test fun relevantMemoriesPreferMatches() {
        val mem = listOf(
            Item(1, "mujhe chai pasand hai", 1),
            Item(2, "meri behen ka naam Riya hai", 2),
            Item(3, "office 9 baje hota hai", 3))
        val r = Brain.relevantMemories(mem, "chai kaise banate hain")
        assertEquals(listOf(1L), r.map { it.id })
    }

    @Test fun relevantMemoriesFallsBackToNewest() {
        val mem = (1L..8L).map { Item(it, "fact $it", it) }
        val r = Brain.relevantMemories(mem, "zzz")
        assertEquals(listOf(4L, 5L, 6L, 7L, 8L), r.map { it.id })
    }
}
