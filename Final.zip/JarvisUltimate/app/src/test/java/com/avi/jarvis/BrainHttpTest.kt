package com.avi.jarvis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.SocketPolicy
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.net.SocketTimeoutException

/** The real HTTP path (Brain.httpCall) against a local MockWebServer: real sockets, real timeouts, real cancellation. */
class BrainHttpTest {
    private lateinit var server: MockWebServer
    @Before fun up() { server = MockWebServer(); server.start() }
    @After fun down() { server.shutdown() }
    private fun url() = server.url("/v1/messages").toString()

    @Test fun postsBodyAndHeadersAndReadsReply() {
        runBlocking {
            server.enqueue(MockResponse().setBody("""{"ok":true}"""))
            val (code, txt) = Brain.httpCall("POST", url(), mapOf("x-api-key" to "k", "content-type" to "application/json"), """{"a":1}""")
            assertEquals(200, code); assertEquals("""{"ok":true}""", txt)
            val rec = server.takeRequest()
            assertEquals("POST", rec.method); assertEquals("k", rec.getHeader("x-api-key")); assertEquals("""{"a":1}""", rec.body.readUtf8())
        }
    }

    @Test fun errorBodyIsReadFor401() {
        runBlocking {
            server.enqueue(MockResponse().setResponseCode(401).setBody("""{"error":{"message":"bad key"}}"""))
            val (code, txt) = Brain.httpCall("POST", url(), emptyMap(), "{}")
            assertEquals(401, code); assertEquals("bad key", Brain.errorDetail(txt))
        }
    }

    @Test fun readTimeoutSurfacesAsSocketTimeout() {
        runBlocking {
            server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE))
            var ex: Throwable? = null
            try { Brain.httpCall("GET", url(), emptyMap(), null, connectMs = 500, readMs = 300) } catch (e: Exception) { ex = e }
            assertTrue("was $ex", ex is SocketTimeoutException)
        }
    }

    @Test fun cancellingTheCoroutineAbortsTheCallQuickly() {
        runBlocking {
            server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE))
            val t0 = System.nanoTime()
            val job = launch(Dispatchers.IO) { Brain.httpCall("GET", url(), emptyMap(), null, readMs = 30_000) }
            delay(300)
            job.cancelAndJoin()
            assertTrue((System.nanoTime() - t0) / 1_000_000 < 5_000)
        }
    }

    @Test fun executeRetriesOn503ThenSucceedsOverRealSockets() {
        runBlocking {
            server.enqueue(MockResponse().setResponseCode(503).setBody("""{"error":{"message":"overloaded"}}"""))
            server.enqueue(MockResponse().setBody("""{"content":[{"type":"text","text":"hello"}]}"""))
            val r = Brain.execute(AiRequest(url(), "k", "m", "s", listOf("user" to "hi"), 10),
                { m, u, h, b -> Brain.httpCall(m, u, h, b) }, sleep = { })
            assertEquals(Ai.Ok("hello"), r)
            assertEquals(2, server.requestCount)
        }
    }

    @Test fun modelDiscoveryOverRealSockets() {
        runBlocking {
            server.enqueue(MockResponse().setBody("""{"data":[{"id":"claude-sonnet-5-5"}]}"""))
            val (ids, err) = Brain.fetchModels(url(), "k", { m, u, h, b -> Brain.httpCall(m, u, h, b) })
            assertEquals(listOf("claude-sonnet-5-5"), ids); assertEquals(null, err)
            val rec = server.takeRequest()
            assertEquals("GET", rec.method); assertTrue(rec.path!!.startsWith("/v1/models")); assertEquals("k", rec.getHeader("x-api-key"))
        }
    }
}
