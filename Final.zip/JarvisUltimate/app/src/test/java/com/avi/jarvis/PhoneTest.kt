package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PhoneTest {
    @Test fun settingsActionMapping() {
        assertEquals("android.settings.WIFI_SETTINGS", Phone.settingsAction("open wifi"))
        assertEquals("android.settings.BLUETOOTH_SETTINGS", Phone.settingsAction("bluetooth settings"))
        assertEquals("android.settings.SETTINGS", Phone.settingsAction("open settings"))
        assertNull(Phone.settingsAction("open whatsapp"))
    }
}
