package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.Random

class PairingLogicTest {
    private fun pairing(status: String, mine: Boolean) = Pairing("p1", "uidX", status, mine, "ABCDEFGHJK")

    @Test fun codeShapeAndAlphabet() {
        val code = PairingLogic.newCode()
        assertEquals(PairingLogic.CODE_LENGTH, code.length)
        assertTrue(PairingLogic.isValid(code))
        assertTrue(code.all { it in PairingLogic.ALPHABET })
        assertFalse(PairingLogic.ALPHABET.any { it in "01OI" })   // look-alikes excluded
    }

    @Test fun codesDoNotCollideInPractice() {
        assertEquals(2000, (1..2000).map { PairingLogic.newCode() }.toSet().size)
    }

    @Test fun codeGenerationIsDeterministicForAGivenRandom() {
        assertEquals(PairingLogic.newCode(Random(7)), PairingLogic.newCode(Random(7)))
    }

    @Test fun normalizeAndValidate() {
        assertEquals("ABCDEFGHJK", PairingLogic.normalize("  abcd-efgh jk "))
        assertTrue(PairingLogic.isValid("ABCDEFGHJK"))
        assertFalse(PairingLogic.isValid("ABCDEFGHJ"))      // too short
        assertFalse(PairingLogic.isValid("ABCDEFGHJ0"))     // forbidden char
        assertFalse(PairingLogic.isValid("abcdefghjk"))     // not normalized
    }

    @Test fun expiryAndAcceptWindow() {
        val exp = 1_000_000L
        assertFalse(PairingLogic.codeExpired(exp, exp)); assertTrue(PairingLogic.codeExpired(exp, exp + 1))
        assertTrue(PairingLogic.acceptWindowOpen(exp, exp + PairingLogic.ACCEPT_GRACE_MS))
        assertFalse(PairingLogic.acceptWindowOpen(exp, exp + PairingLogic.ACCEPT_GRACE_MS + 1))
    }

    @Test fun onlyTheNonRequesterCanAcceptAPendingRequest() {
        assertTrue(PairingLogic.canAccept(pairing("pending", mine = false)))
        assertFalse(PairingLogic.canAccept(pairing("pending", mine = true)))
        assertFalse(PairingLogic.canAccept(pairing("active", mine = false)))
        assertFalse(PairingLogic.canAccept(pairing("revoked", mine = false)))
    }

    @Test fun credentialChecks() {
        assertNull(PairingLogic.checkCreds("a@b.co", "secret1"))
        assertEquals("Email sahi nahi hai.", PairingLogic.checkCreds("not-an-email", "secret1"))
        assertEquals("Email sahi nahi hai.", PairingLogic.checkCreds("a@b", "secret1"))
        assertTrue(PairingLogic.checkCreds("a@b.co", "123")!!.contains("6"))
    }

    @Test fun statusLabels() {
        assertTrue(PairingLogic.statusLabel(pairing("active", true)).startsWith("Active"))
        assertTrue(PairingLogic.statusLabel(pairing("pending", true)).contains("intezaar"))
        assertTrue(PairingLogic.statusLabel(pairing("pending", false)).contains("accept kare"))
    }

    // ---- parity between the app and firestore.rules (unit tests run with working dir = app/) ----
    private val rules get() = File("../firestore.rules").readText()
    private val cloud get() = File("src/main/java/com/avi/jarvis/Cloud.kt").readText()

    @Test fun rulesUseTheSameConstantsAsTheApp() {
        assertTrue(rules.contains("duration.value(${PairingLogic.ACCEPT_GRACE_MS / 60_000}, 'm')"))
        assertTrue(rules.contains("[A-HJ-NP-Z2-9]{${PairingLogic.CODE_LENGTH}}"))
        assertEquals("ABCDEFGHJKLMNPQRSTUVWXYZ23456789", PairingLogic.ALPHABET)
    }

    @Test fun everyFieldCloudKtWritesIsWhitelistedByTheRules() {
        val fields = listOf("ownerUid", "expiresAt", "purgeAt", "used",                       // pairCodes
            "members", "requestedBy", "status", "codeId", "createdAt",                         // pairings
            "email", "device", "updatedAt")                                                    // users
        for (f in fields) {
            assertTrue("rules missing $f", rules.contains("'$f'"))
            assertTrue("Cloud.kt missing $f", cloud.contains("\"$f\""))
        }
    }

    @Test fun acceptBatchBurnsTheCodeAndRulesRequireIt() {
        assertTrue(cloud.contains("batch.update(db.collection(\"pairCodes\").document(p.codeId), \"used\", true)"))
        assertTrue(rules.contains("getAfter(/databases/\$(db)/documents/pairCodes/\$(resource.data.codeId)).data.used == true"))
    }
}
