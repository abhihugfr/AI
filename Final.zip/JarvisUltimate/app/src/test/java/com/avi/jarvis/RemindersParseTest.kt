package com.avi.jarvis
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class RemindersParseTest {
    private val now = 1_700_000_000_000L

    @Test fun relativeMinutesHinglish() {
        val p = Reminders.parse("10 minute baad chai yaad dilao", now)!!
        assertEquals(now + 600_000L, p.first)
        assertEquals("chai", p.second)
    }

    @Test fun relativeHoursEnglish() {
        val p = Reminders.parse("remind me in 2 hours to call mom", now)!!
        assertEquals(now + 7_200_000L, p.first)
        assertEquals("call mom", p.second)
    }

    @Test fun hindiHours() {
        val p = Reminders.parse("2 ghante baad dawai yaad dilana", now)!!
        assertEquals(now + 7_200_000L, p.first)
        assertEquals("dawai", p.second)
    }

    @Test fun absoluteTimeIsInFutureAndTwentyHundred() {
        val p = Reminders.parse("remind me at 8 pm to go to gym", now)!!
        assertTrue(p.first > now)
        assertEquals("go to gym", p.second)
        val cal = Calendar.getInstance().apply { timeInMillis = p.first }
        assertEquals(20, cal.get(Calendar.HOUR_OF_DAY))
        assertEquals(0, cal.get(Calendar.MINUTE))
    }

    @Test fun noTimeReturnsNull() {
        assertNull(Reminders.parse("remind me to call mom", now))
    }

    @Test fun hugeNumbersDoNotCrashAndAreRejected() {
        assertNull(Reminders.parse("99999999999999999999 minutes baad chai", now))
        assertNull(Reminders.parse("100001 minute baad chai", now))
        assertNull(Reminders.parse("400 days baad chai", now))
    }

    @Test fun oneYearAheadIsStillAllowed() {
        val p = Reminders.parse("365 days baad birthday", now)!!
        assertEquals(now + 365L * 86_400_000L, p.first)
    }
}
