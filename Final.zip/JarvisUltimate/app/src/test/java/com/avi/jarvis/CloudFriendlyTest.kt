package com.avi.jarvis
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Firebase error -> user message mapping (Cloud.friendly). Pure exception classes, no Firebase backend needed. */
class CloudFriendlyTest {
    @Test fun authErrors() {
        fun m(code: String) = Cloud.friendly(FirebaseAuthException(code, "raw"))
        assertTrue(m("ERROR_WRONG_PASSWORD").contains("password"))
        assertTrue(m("ERROR_INVALID_CREDENTIAL").contains("password"))
        assertTrue(m("ERROR_USER_NOT_FOUND").contains("account nahi"))
        assertTrue(m("ERROR_EMAIL_ALREADY_IN_USE").contains("registered"))
        assertTrue(m("ERROR_WEAK_PASSWORD").contains("6"))
        assertTrue(m("ERROR_INVALID_EMAIL").contains("Email"))
        assertEquals("raw", m("ERROR_SOMETHING_NEW"))
    }

    @Test fun firestoreErrors() {
        fun m(c: FirebaseFirestoreException.Code) = Cloud.friendly(FirebaseFirestoreException("raw", c))
        assertTrue(m(FirebaseFirestoreException.Code.PERMISSION_DENIED).contains("Permission"))
        assertTrue(m(FirebaseFirestoreException.Code.UNAVAILABLE).contains("internet"))
        assertEquals("raw", m(FirebaseFirestoreException.Code.ABORTED))
    }

    @Test fun networkAndGeneric() {
        assertTrue(Cloud.friendly(FirebaseNetworkException("net")).contains("Internet"))
        assertEquals("boom", Cloud.friendly(RuntimeException("boom")))
        assertEquals("Error", Cloud.friendly(RuntimeException()))
    }

    @Test fun timeoutMessage() {
        val e = runBlocking {
            try { withTimeout(10) { delay(5_000) }; null } catch (t: TimeoutCancellationException) { t }
        }
        assertNotNull(e)
        assertTrue(Cloud.friendly(e!!).contains("jawab nahi aaya"))
    }
}
