#!/usr/bin/env sh
# Needs Gradle 8.x installed. Generates the genuine wrapper locally.
gradle wrapper --gradle-version 8.7 --distribution-type bin
