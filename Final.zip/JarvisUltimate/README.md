# JARVIS Ultimate v0.4 (second-round repair)
Kotlin + Jetpack Compose. Package `com.avi.jarvis`, minSdk 26, targetSdk 34, AGP 8.2.2, Gradle 8.7, Kotlin 1.9.24, JDK 17.

**Status: NOT compiled, NOT unit-tested by Kotlin, NOT linted, NOT run on a device.** The authoring sandbox had no Gradle,
Android SDK or network. Real evidence so far: a 22/22 real-socket HTTP harness (Java port) and static cross-checks.
Read REPORT.md first. The first run of the GitHub workflow is the real build/test/lint verdict.

Docs: REPORT.md | BUILD_STEPS.md (Hinglish) | TESTING.md | AUDIT.md | SETUP_FIREBASE.md | ARCHITECTURE.md | docs/PROXY.md
