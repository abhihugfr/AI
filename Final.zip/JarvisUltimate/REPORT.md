# JarvisUltimate_Final: second-round repair report

## 0. What I could and could not do (read this first)
| Requested | Outcome |
|---|---|
| Genuine Gradle wrapper files in the ZIP | **NOT DONE.** `gradle-wrapper.jar` can only come from Gradle itself or Gradle's servers; the sandbox has no Gradle and no network. I did not hand-write or fake one. Instead: workflow `generate-wrapper.yml` runs `gradle wrapper` (official) and **commits** `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar` into your repo (one click). `scripts/make-wrapper.sh/.bat` do the same locally. `gradle-wrapper.properties` (Gradle 8.7) is included. CI does not depend on the wrapper. |
| Run the actual Gradle build and tests | **NOT POSSIBLE here** (no Gradle, Kotlin compiler, Android SDK, emulator, network). Probed again this round: all hosts unreachable, no Gradle/Kotlin artifacts on disk. |
| APK | **NOT BUILT.** No APK is included. |

## 1. Fixed issues
### Confirmed issue list from your message
1. **Wrapper**: see section 0 (not possible offline; auto-generate + commit workflow added).
2. **Pairing acceptance**: I re-read Cloud.kt and the rules. The accepter is always the code *owner* (the create rule forces `ownerUid in members` and `ownerUid != requester`, and only the non-requester may accept), so the owner-only rule on `pairCodes` was satisfied; the failure as described does not follow from the code. I did find and fix two **real** defects in the same flow: (A) single-use was not enforced, several pending requests on one code could all be accepted; (B) accepting after the code document was TTL-purged failed (NOT_FOUND), and TTL was on `expiresAt`. New design, **rules-only and atomic**: one batch flips `pairings.status = active` and burns `pairCodes.used = true`; rules allow the status change only if caller = code owner and not requester, `get(code).used == false`, expiry + 15 min not passed, and `getAfter(code).used == true`. A Cloud Function was considered and rejected (needs the paid Blaze plan, adds attack surface, no extra guarantee). TTL moved to a separate `purgeAt` field. Friendly error when denied/not found.
3. **CI runs configuration, compile, unit tests, lint; lint not silent**: `abortOnError = true` in Gradle; no `continue-on-error` anywhere.
4. **APK only after all checks**: upload step comes after config > manifest > compile > tests > lint > assemble and runs only on success.
5. **Rules vs every Cloud.kt operation**: all 8 operations and 3 field whitelists cross-checked (table in 3). Rules tightened (`hasAll`, `createdAt == request.time`, code regex, users whitelist).
6. **Manifest permissions vs code**: 7 declared, all used, none missing; flashlight, volume, media keys, startActivity need none (table in 3). `configChanges` added.
7. **API tests** (discovery, key validation, timeout, retries, error responses): 20 Kotlin tests + a real-socket harness (22/22 pass here). Details in 4.
8. **Kotlin file inspection**: runtime-crash/lifecycle fixes listed below.
9. **Firebase tests**: `CloudFriendlyTest` (error mapping), `PairingLogicTest` (code/expiry/accept rule, **rules<->Cloud.kt parity**), and 30 emulator tests for the rules (`firebase-tests/`).
10. **Device claims**: none made. See 6.

### Runtime / lifecycle fixes found by reading every Kotlin file
- Reminder text with a huge number threw `NumberFormatException` (crash) -> guarded (`toLongOrNull`, 100000 units, 366 days).
- Wake service could stay deaf forever if TTS failed or never called back -> speak() result checked + 20 s watchdog + single `finishSpeak()`.
- Foreground mic service without permission could crash (Android 14) -> permission check + try/catch + graceful stop.
- Activity recreation on rotation silently cancelled an in-flight AI request -> `configChanges`.
- Encrypted-storage failure at startup could crash -> private-plain fallback + visible warning in About.
- AI call: policy extracted into testable `execute()`; `ask()` and `listModels()` also reject non-https endpoints.
Preserved: all earlier features (chat, voice, wake word, phone commands, memory/notes/reminders, pairing UI) are unchanged in behaviour.

## 2. Build output
**None. The Gradle build was not run.** No compile errors seen, because nothing was compiled; this does not mean there are none.

## 3. Static / cross-check results (actually run)
**Manifest permission audit**
| Permission | Declared | Used by |
|---|---|---|
| INTERNET | yes | Brain, Cloud |
| ACCESS_NETWORK_STATE | yes | Phone.online/network |
| SET_ALARM | yes | Phone.alarm (ACTION_SET_ALARM) |
| RECORD_AUDIO | yes | WakeService (runtime request in UI/Settings) |
| POST_NOTIFICATIONS | yes | reminders, wake notice (runtime request in MainActivity/Settings) |
| FOREGROUND_SERVICE / _MICROPHONE | yes | WakeService (type `microphone`) |
No permission needed: flashlight `setTorchMode`, `adjustStreamVolume`, media key events, `startActivity`. No location/camera/contacts/SMS permissions used.

**Rules vs Cloud.kt**
| Cloud.kt operation | Rule that covers it | Static check | Emulator test (not run) |
|---|---|---|---|
| saveProfile `users.set(merge)` | users create/update whitelist | OK | yes |
| createPairCode `pairCodes.set` | pairCodes create (owner, 4 keys, regex, <=30 min) | OK | yes |
| joinWithCode `pairCodes.get` | pairCodes get | OK | yes |
| joinWithCode `pairings.add` | pairings create (members, requester, pending, unused+unexpired code) | OK | yes |
| pairings() query `array-contains` | pairings read | OK | yes |
| accept batch (pairings.status + pairCodes.used) | pairings update (owner, `get`/`getAfter`) + pairCodes update (false->true) | OK | yes |
| revoke | pairings update `revoked` by any member | OK | yes |
| (no deletes in Cloud.kt) | deletes denied on pairings | OK | yes |

## 4. Unit test results
**Executed here, real:** `tools/http-harness/Harness.java` (Java port of the AI request policy against a real local HTTP server): **22 passed, 0 failed** (docs/http-harness-output.txt): success, key only in header, version header, body delivered, 401/403/404/400/418 not retried with error body read, 429,429,200 recovers with backoff 1000/2000, 500/502/503/504/529 x4 stop with backoff 1000/2000/4000, read timeout (4 attempts), timeout-then-success, connection refused, garbage 200 body, model discovery GET `/v1/models?limit=50` + 401 body, cancel aborts a blocked call in ~0.4 s. Caveat: this is a Java port on a JVM, not the Kotlin code and not Android's HttpURLConnection.
**Python mirrors (real, logic only):** reminder parsing, overflow guard, command routing (hijack cases), memory relevance.
**Kotlin unit tests: written (53) but NOT RUN** (`BrainExecuteTest` 14, `BrainHttpTest` 6 MockWebServer, `BrainTest` 10, `PairingLogicTest` 11, `RemindersParseTest` 7, `CloudFriendlyTest` 4, `PhoneTest` 1). **Rules tests: written (30), NOT RUN.**

## 5. Lint results
**Not run.** Configured strict (`abortOnError = true`), so a lint error will fail CI and block the APK. Reports upload as the `reports` artifact. I cannot predict lint output; warnings (deprecations, `DefaultLocale`, newer-dependency notices) do not fail it.

## 6. Remaining limitations (honest)
- Nothing here is compile-verified; expect to iterate on the first CI run. Send the failing step's log.
- No on-device testing of any feature: voice recognition/TTS (Hindi/English language data is device-dependent), the wake word (a SpeechRecognizer loop, not low-power; may beep; may use cloud recognition; Android blocks app launches from the background), flashlight, volume/mute/media keys (work only with an active media app), alarms (open the clock app), reminders (WorkManager: can be delayed by Doze), notifications, Firebase login/pairing against a real project, real Anthropic calls with a real key.
- Rules use `getAfter`; correctness is argued from the documented semantics and tests exist, but they have not been run on the emulator.
- Pairing code readable by id by any signed-in user (needed for join); mitigated by 50-bit code, 10 min, single use; add App Check for more.
- API key is stored encrypted on the device; for anything shared use a backend proxy (docs/PROXY.md, not implemented).
- `security-crypto` may show upstream deprecation warnings.
- Not implemented (deliberately, secure flow not deliverable/testable here): messaging, FCM, signals, remote ring, location, QR pairing, AI-to-AI, automation engine.
- Stop-generation works by cancelling/disconnecting the request (the API is not streamed).

## 7. How to get the real results (about 20 minutes)
1. Private GitHub repo, upload everything (including `.github`).
2. Actions > Generate Gradle wrapper > Run (commits the official wrapper). `git pull`.
3. Actions > Android CI. Green = all gates passed and `jarvis-debug-apk` exists. Red = send me the failing step's log.
4. Install the APK, try the commands in BUILD_STEPS.md, and tell me what actually fails on your phone.
