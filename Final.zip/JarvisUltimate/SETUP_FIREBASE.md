# Firebase setup (private; free Spark plan is enough for the current features)
1. console.firebase.google.com > Add project (Analytics off).
2. Add Android app, package `com.avi.jarvis`. Download `google-services.json` into `app/` (git-ignored, never commit).
   For GitHub Actions: `base64 -w0 app/google-services.json` > repo Settings > Secrets > `GOOGLE_SERVICES_JSON_B64`.
3. Authentication > enable **Email/Password**.
4. Firestore Database > create (production mode) > Rules > paste the whole `firestore.rules` > Publish.
5. Firestore > TTL policies: collection `pairCodes`, field **`purgeAt`** (NOT expiresAt). Codes are deleted 2 days after creation;
   `expiresAt` (10 min) and the 15-minute accept window are enforced by the rules, so TTL timing does not matter.
6. Rebuild. On BOTH phones use the same project, a different account on each phone.
7. Pairing test: phone A "Create pairing code" > phone B enters it > "Send pairing request" > phone A "Refresh" > "Accept".

## How accept works (atomic, no backend)
Phone A (code owner) sends ONE batched write: `pairings/{id}.status = active` + `pairCodes/{code}.used = true`.
firestore.rules allow the status change only if: caller is the code owner and not the requester, the code is currently
unused and not past expiry+15 min, and `getAfter(code).used == true` (the same batch burns it). Hence a code activates at
most one pairing, and nothing can be activated without burning the code.
A Cloud Function would add a server-side path but needs the paid Blaze plan and more attack surface; not needed for this.

## Test the rules (needs Node 20 + Java 17)
`cd firebase-tests && npm install && npm test` (starts the Firestore emulator). Runs automatically in the CI job `firestore-rules`.

## Not implemented
Messaging, signals, remote ring, location, FCM, QR pairing, AI-to-AI. The secure flow for these needs Cloud Functions + FCM
and device testing; they are deliberately not shipped half-built.
Weak spot: any signed-in user can `get` a pairCode by id (needed for join). 50-bit random code + 10 min + single use limits it;
enable Firebase App Check for real protection.
