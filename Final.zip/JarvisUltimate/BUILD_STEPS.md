# JARVIS APK kaise banayein (simple Hinglish)

## Raasta A: GitHub se (recommended, laptop par kuch install nahi)
1. github.com > New repository > **Private** > naam `jarvis`.
2. Zip extract karo, saari files upload karo (**`.github` folder bhi**). API key / `google-services.json` kabhi mat daalo.
3. **Gradle wrapper (ek baar):** repo > Actions > **Generate Gradle wrapper** > Run workflow. Ye genuine official wrapper files
   (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`) banakar repo mein khud commit kar deta hai. Phir laptop par `git pull`.
   Is step ke bina bhi CI chalti hai.
4. Actions > **Android CI** chalega. Ye steps order se chalte hain, koi bhi fail ho to aage nahi badhta:
   configuration > manifest > compile > unit tests > **lint (strict)** > APK build > APK upload.
   Alag job `firestore-rules` Firebase rules ko emulator par test karta hai.
5. Sab green hone par run kholo > Artifacts > `jarvis-debug-apk`. Ye tabhi milega jab saare checks pass hon.
6. Red ho to laal step ka error text Claude ko bhejo. `reports` artifact mein test aur lint report hoti hai.

## Raasta B: Android Studio
Open > folder `JarvisUltimate` > Sync > Build > Build APK(s). APK: `app/build/outputs/apk/debug/app-debug.apk`.
(Gradle wrapper local par chahiye to: Gradle install karke `scripts/make-wrapper.sh` ya `.bat` chalao.)

## App chalane ke baad
Settings > API key paste > Save > Load models > Test connection. Chat mein: `battery`, `flashlight on`, `open whatsapp`,
`volume up`, `yaad rakho mujhe chai pasand hai`, `10 minute baad paani peena yaad dilao`, `note: doodh lana`, `alarm 7:30 am`, `share text hello`.
Ye sab abhi kisi asli phone par test nahi hue hain, aap pehli baar chalayenge to result mujhe batana.
