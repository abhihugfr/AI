# Backend proxy evaluation (keep the API key off the phone)
Today: the user types their own Anthropic key; it is stored encrypted on that phone only, never in the APK or repo.
That is acceptable for a private app you install yourself. A key on any device can be extracted by someone with root, so for
anything shared, use a proxy.

Design: Firebase Cloud Function (HTTPS callable) holds the key as a secret (`firebase functions:secrets:set ANTHROPIC_API_KEY`),
checks `request.auth` (Firebase Auth user), rate-limits per uid, forwards the body to `https://api.anthropic.com/v1/messages`
and returns the response. The app then sets Settings > API endpoint to the function URL.
Needs the Blaze (pay-as-you-go) plan. Not implemented in this repo; the endpoint field and https check are the client side of it.
The proxy must also accept the app's Firebase ID token (add an `Authorization: Bearer` header in Brain.kt when you build it).
